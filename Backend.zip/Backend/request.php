<?php
header("Access-Control-Allow-Origin: *");
ini_set("display_errors","On");
error_reporting(E_ALL);
date_default_timezone_set("Asia/Hong_Kong");
include('require_files.php');

$result = json_encode(array("result"=>"fail", "data"=>"request fail"));
if(array_key_exists('current_datetime_string',$_POST)){
	$result = GetCurrentTimeString();
}

//-------------------

if(array_key_exists('upload_file',$_POST)){
	$result = UploadImage($_POST['upload_file']);
}

//-------------------

if(array_key_exists('user_register',$_POST)){
	$result = UserRegister($_POST['user_register']);
}

if(array_key_exists('staff_register',$_POST)){
	$result = StaffRegister($_POST['staff_register']);
}

if(array_key_exists('update_user',$_POST)){
	$result = UpdateUser($_POST['update_user']);
}

if(array_key_exists('login',$_POST)){
	$result = Login($_POST['login']);
}

if(array_key_exists('check_email',$_POST)){
	$result = CheckEmail($_POST['check_email']);
}

if(array_key_exists('check_phone',$_POST)){
	$result = CheckPhone($_POST['check_phone']);
}

if(array_key_exists('get_all_user',$_POST)){
	$result = GetAllUser();
}

if(array_key_exists('get_user_by_id',$_POST)){
	$result = GetUserById($_POST['get_user_by_id']);
}

if(array_key_exists('request_password',$_POST)){
	$result = ResetPasswordRequest($_POST['request_password']);
}

if(array_key_exists('facebook_register',$_POST)){
	$result = FacebookRegister($_POST['facebook_register']);
}

if(array_key_exists('facebook_login',$_POST)){
	$result = FacebookLogin($_POST['facebook_login']);
}

if(array_key_exists('google_register',$_POST)){
	$result = GoogleRegister($_POST['google_register']);
}

if(array_key_exists('google_login',$_POST)){
	$result = GoogleLogin($_POST['google_login']);
}

if(array_key_exists('apple_register',$_POST)){
	$result = AppleRegister($_POST['apple_register']);
}

if(array_key_exists('apple_login',$_POST)){
	$result = AppleLogin($_POST['apple_login']);
}

if(array_key_exists('add_apple_user',$_POST)){
	$result = AddAppleUser($_POST['add_apple_user']);
}

if(array_key_exists('get_apple_user',$_POST)){
	$result = GetAppleUser($_POST['get_apple_user']);
}

//-------------------

if(array_key_exists('new_event',$_POST)){
	$result = NewEvent($_POST['new_event']);
}

if(array_key_exists('update_event',$_POST)){
	$result = UpdateEvent($_POST['update_event']);
}

if(array_key_exists('get_all_event',$_POST)){
	$result = GetAllEvent();
}

if(array_key_exists('get_event_by_id',$_POST)){
	$result = GetEventById($_POST['get_event_by_id']);
}

if(array_key_exists('get_event_by_id_list',$_POST)){
	$result = GetEventByIdList($_POST['get_event_by_id_list']);
}

//-------------------

if(array_key_exists('new_album',$_POST)){
	$result = NewAlbum($_POST['new_album']);
}

if(array_key_exists('update_album',$_POST)){
	$result = UpdateAlbum($_POST['update_album']);
}

if(array_key_exists('get_all_album',$_POST)){
	$result = GetAllAlbum();
}

if(array_key_exists('get_album_by_id',$_POST)){
	$result = GetAlbumById($_POST['get_album_by_id']);
}

//-------------------

if(array_key_exists('new_comment',$_POST)){
	$result = NewComment($_POST['new_comment']);
}

if(array_key_exists('update_comment',$_POST)){
	$result = UpdateComment($_POST['update_comment']);
}

if(array_key_exists('get_all_comment',$_POST)){
	$result = GetAllComment();
}

if(array_key_exists('get_comment_by_id',$_POST)){
	$result = GetCommentById($_POST['get_comment_by_id']);
}

//-------------------

if(array_key_exists('new_performer',$_POST)){
	$result = NewPerformer($_POST['new_performer']);
}

if(array_key_exists('update_performer',$_POST)){
	$result = UpdatePerformer($_POST['update_performer']);
}

if(array_key_exists('get_all_performer',$_POST)){
	$result = GetAllPerformer();
}

if(array_key_exists('get_performer_by_id',$_POST)){
	$result = GetPerformerById($_POST['get_performer_by_id']);
}

//-------------------

if(array_key_exists('new_notification',$_POST)){
	$result = NewNotification($_POST['new_notification']);
}

if(array_key_exists('update_notification',$_POST)){
	$result = UpdateNotification($_POST['update_notification']);
}

if(array_key_exists('get_all_notification',$_POST)){
	$result = GetAllNotification();
}

if(array_key_exists('get_notification_by_id',$_POST)){
	$result = GetNotificationById($_POST['get_notification_by_id']);
}

//-------------------

if(array_key_exists('new_product',$_POST)){
	$result = NewProduct($_POST['new_product']);
}

if(array_key_exists('update_product',$_POST)){
	$result = UpdateProduct($_POST['update_product']);
}

if(array_key_exists('get_all_product',$_POST)){
	$result = GetAllProduct();
}

if(array_key_exists('get_product_by_id',$_POST)){
	$result = GetProductById($_POST['get_product_by_id']);
}

if(array_key_exists('get_product_by_id_list',$_POST)){
	$result = GetProductByIdList($_POST['get_product_by_id_list']);
}

//-------------------

if(array_key_exists('new_coupon',$_POST)){
	$result = NewCoupon($_POST['new_coupon']);
}

if(array_key_exists('update_coupon',$_POST)){
	$result = UpdateCoupon($_POST['update_coupon']);
}

if(array_key_exists('get_all_coupon',$_POST)){
	$result = GetAllCoupon();
}

if(array_key_exists('get_coupon_by_id',$_POST)){
	$result = GetCouponById($_POST['get_coupon_by_id']);
}

if(array_key_exists('get_coupon_by_code',$_POST)){
	$result = GetCouponByCode($_POST['get_coupon_by_code']);
}

//-------------------

if(array_key_exists('new_vote',$_POST)){
	$result = NewVote($_POST['new_vote']);
}

if(array_key_exists('update_vote',$_POST)){
	$result = UpdateVote($_POST['update_vote']);
}

if(array_key_exists('get_all_vote',$_POST)){
	$result = GetAllVote();
}

if(array_key_exists('get_vote_by_id',$_POST)){
	$result = GetVoteById($_POST['get_vote_by_id']);
}

//-------------------

if(array_key_exists('new_vote_record',$_POST)){
	$result = NewVoteResult($_POST['new_vote_record']);
}

if(array_key_exists('update_vote_record',$_POST)){
	$result = UpdateVoteResult($_POST['update_vote_record']);
}

if(array_key_exists('get_all_vote_record',$_POST)){
	$result = GetAllVoteResult();
}

if(array_key_exists('get_vote_record_by_id',$_POST)){
	$result = GetVoteResultById($_POST['get_vote_record_by_id']);
}

if(array_key_exists('get_vote_record_by_vote_id',$_POST)){
	$result = GetVoteResultByVoteId($_POST['get_vote_record_by_vote_id']);
}

//-------------------

if(array_key_exists('new_ticket',$_POST)){
	$result = NewTicket($_POST['new_ticket']);
}

if(array_key_exists('update_ticket',$_POST)){
	$result = UpdateTicket($_POST['update_ticket']);
}

if(array_key_exists('get_all_ticket',$_POST)){
	$result = GetAllTicket();
}

if(array_key_exists('get_ticket_by_id',$_POST)){
	$result = GetTicketById($_POST['get_ticket_by_id']);
}

if(array_key_exists('get_ticket_by_user',$_POST)){
	$result = GetTicketByUser($_POST['get_ticket_by_user']);
}

if(array_key_exists('get_ticket_by_order',$_POST)){
	$result = GetTicketByOrder($_POST['get_ticket_by_order']);
}

//-------------------

if(array_key_exists('new_redeem',$_POST)){
	$result = NewRedeem($_POST['new_redeem']);
}

if(array_key_exists('update_redeem',$_POST)){
	$result = UpdateRedeem($_POST['update_redeem']);
}

if(array_key_exists('get_all_redeem',$_POST)){
	$result = GetAllRedeem();
}

if(array_key_exists('get_redeem_by_id',$_POST)){
	$result = GetRedeemById($_POST['get_redeem_by_id']);
}

if(array_key_exists('get_redeem_by_user',$_POST)){
	$result = GetRedeemByUser($_POST['get_redeem_by_user']);
}

//-------------------

if(array_key_exists('new_payment',$_POST)){
	$result = NewPayment($_POST['new_payment']);
}

// if(array_key_exists('update_redeem',$_POST)){
// 	$result = UpdateRedeem($_POST['update_redeem']);
// }

if(array_key_exists('get_all_payment',$_POST)){
	$result = GetAllPayment();
}

if(array_key_exists('get_payment_by_id',$_POST)){
	$result = GetPaymentById($_POST['get_payment_by_id']);
}

if(array_key_exists('get_payment_by_order',$_POST)){
	$result = GetPaymentByOrder($_POST['get_payment_by_order']);
}

if(array_key_exists('get_payment_by_user',$_POST)){
	$result = GetPaymentByUser($_POST['get_payment_by_user']);
}

//-------------------

if(array_key_exists('add_credit',$_POST)){
	$result = AddCredit($_POST['add_credit']);
}

if(array_key_exists('use_credit',$_POST)){
	$result = UseCredit($_POST['use_credit']);
}

if(array_key_exists('update_credit',$_POST)){
	$result = UpdateCredit($_POST['update_credit']);
}

if(array_key_exists('get_all_credit',$_POST)){
	$result = GetAllCredit();
}

if(array_key_exists('get_credit_by_id',$_POST)){
	$result = GetCreditById($_POST['get_credit_by_id']);
}

if(array_key_exists('get_credit_of_user',$_POST)){
	$result = GetCreditOfUser($_POST['get_credit_of_user']);
}

//-------------------

echo $result;
?>
