<?php
header("Access-Control-Allow-Origin: *");
ini_set("display_errors", "On");
error_reporting(E_ERROR);
date_default_timezone_set("Asia/Hong_Kong");
include_once('databasetool.php');
include_once('checker.php');
include_once('encryption.php');

// Agency ---------------------------------------------------------------------------------------------------------------- //

function ArtistInit($data)
{
  if (!isset($data['id'])) {
    $data['id'] = NewId('Voting_Artist');
  }

  if (!isset($data['data_type'])) {
    $data['data_type'] = "voting_artist_data";
  }

  if (!isset($data['create_date'])) {
    $data['create_date'] = GetCurrentTimeString();
  }

  if (!isset($data['artist_origin'])) {
    $data['artist_origin'] = "";
  }

  if (!isset($data['artist_label'])){
    $data['artist_label'] = "";
  }

  if (!isset($data['is_cash_member'])) {
    $data['is_cash_member'] = "";
  }

  if (!isset($data['contact_person'])) {
    $data['contact_person'] = "";
  }

  if (!isset($data['role_of_contact_person'])) {
    $data['role_of_contact_person'] = "";
  }

  if (!isset($data['contact_email'])) {
    $data['contact_email'] = "";
  }

  if (!isset($data['contact_number'])) {
    $data['contact_number'] = "";
  }

  if (!isset($data['facebook_link'])) {
    $data['facebook_link'] = "";
  }

  if (!isset($data['instagram_link'])) {
    $data['instagram_link'] = "";
  }

  if (!isset($data['youtube_link'])) {
    $data['youtube_link'] = "";
  }

  if (!isset($data['website_link'])) {
    $data['website_link'] = "";
  }

  if (!isset($data['artist_photo'])) {
    $data['artist_photo'] = "";
  }

  if (!isset($data['status'])) {
    $data['status'] = "active";
  }

  return $data;
}



function NewArtist($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if(      !array_key_exists("user_id", $temp_data) 
        || !array_key_exists("artist_name", $temp_data)
        || !array_key_exists("artist_origin", $temp_data)
        || !array_key_exists("artist_label", $temp_data)
        || !array_key_exists("is_cash_member", $temp_data)
        || !array_key_exists("contact_person", $temp_data)
        || !array_key_exists("role_of_contact_person", $temp_data)
        || !array_key_exists("contact_email", $temp_data)
        || !array_key_exists("contact_number", $temp_data)
        || !array_key_exists("artist_photo", $temp_data)
    ){
    return json_encode(array("result" => "fail", "data" => "missing must key"));
  }

  if(!CheckEmailFormat($temp_data["contact_email"])){
    return json_encode(array("result"=>"fail","data"=>"email format error"));
  }

  $get_user_data = json_decode( GetSingleDataByDataTypeAndId(json_encode(array("data_type"=>"voting_user_data","id"=>$temp_data['user_id']))) ,true);
  if($get_user_data['result'] !="success" || $get_user_data['data'] ==null){
      return json_encode($get_user_data);
  }
  if($get_user_data['data']["artist_id"] != -1){
    return json_encode(array("result"=>"fail","data"=>"already become artist,ready to rock!!!!!!"));
}

  $temp_data = ArtistInit($temp_data);

  //N1QL
  $query = CouchbaseN1qlQuery::fromString("UPSERT INTO " . BucketName() . " as data (KEY, VALUE) VALUES (\"voting_artist_" . $temp_data['id'] . "\"," . json_encode($temp_data) . ") RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]["data"] != null) {

            $update_user = json_decode(UpdateUser(json_encode(array("id"=>$temp_data['user_id'],"artist_id"=>$temp_data['id']))) ,true);
            if($update_user['result'] !="success" || $update_user['data'] ==null){
                return json_encode($update_user);
            }
            $result["data"] = $json["rows"][0]["data"];
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function UpdateArtist($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if (!array_key_exists('id', $temp_data)) {
    return json_encode(array("result" => "fail", "data" => "value missing"));
  }
  $update_string = "";

  

  if (isset($temp_data['artist_name'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " artist_name = " . json_encode($temp_data['artist_name']) . " ";
  }

  if (isset($temp_data['artist_origin'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " artist_origin = " . json_encode($temp_data['artist_origin']) . " ";
  }

  if (isset($temp_data['artist_label'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " artist_label = " . json_encode($temp_data['artist_label']) . " ";
  }

  if (isset($temp_data['is_cash_member'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    
    $update_string .= ($temp_data['is_cash_member']) ? ' is_cash_member = true' : ' is_cash_member = false'. " ";
  }

  if (isset($temp_data['contact_person'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " contact_person = " . json_encode($temp_data['contact_person']) . " ";
  }

  if (isset($temp_data['role_of_contact_person'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " role_of_contact_person = " . json_encode($temp_data['role_of_contact_person']) . " ";
  }

  if (isset($temp_data['contact_email'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " contact_email = " . json_encode($temp_data['contact_email']) . " ";
  }

  if (isset($temp_data['contact_number'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " contact_number = " . json_encode($temp_data['contact_number']) . " ";
  }

  if (isset($temp_data['facebook_link'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " facebook_link = " . json_encode($temp_data['facebook_link']) . " ";
  }


  if (isset($temp_data['instagram_link'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " instagram_link = " . json_encode($temp_data['instagram_link']) . " ";
  }

  if (isset($temp_data['youtube_link'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " youtube_link = " . json_encode($temp_data['youtube_link']) . " ";
  }

  if (isset($temp_data['website_link'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " website_link = " . json_encode($temp_data['website_link']) . " ";
  }

  if (isset($temp_data['artist_photo'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " artist_photo = " . json_encode($temp_data['artist_photo']) . " ";
  }

  if($update_string==""){
    return json_encode(array("result"=>"fail","data"=>"nothing update"));
  }

  $query = CouchbaseN1qlQuery::fromString("update " . BucketName() . " as data set " . $update_string . " where id=" . $temp_data['id'] . " and data_type='voting_artist_data' RETURNING * ;");
  
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    // return json_encode($json);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]['data'] != null) {
          $result['data'] = $json["rows"][0]['data'];
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}





?>