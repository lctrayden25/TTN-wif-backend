<?php
// function ServerLink(){ return "http://167.99.69.151:8091"; }
function ServerLink(){ return "http://localhost:8091"; }
function ServerAc(){ return "ttn_admin"; }
function ServerPw(){ return "Ttn2020!"; }
function BucketName(){ return "TTN"; }
function WebsiteLink(){return "http://206.189.153.177:8091";}
function is_connected(){
  // $connected = @fsockopen("167.99.69.151", 8091); //website, port  (try 80 or 443)
  $connected = @fsockopen("127.0.0.1", 8091); //website, port  (try 80 or 443)
    if ($connected){
        $is_conn = true; //action when connected
        fclose($connected);
    }else{
        $is_conn = false; //action in connection failure
    }
    return $is_conn;
}
function Bucket(){
  // // $authenticator = new \Couchbase\PasswordAuthenticator();
  // // $authenticator->username(ServerAc())->password(ServerPw());
  //
  // // Connect to Couchbase Server
  // $cluster = new CouchbaseCluster(ServerLink());
  //
  // // Authenticate, then open bucket
	// $cluster->authenticateAs(ServerAc(),ServerPw());
  // // $cluster->authenticate($authenticator);
  // $bucket = $cluster->openBucket("intervill",'');
  // return $bucket;

	$cluster = new \Couchbase\Cluster(ServerLink());
	$cluster->authenticateAs(ServerAc(),ServerPw());
	return $cluster->openBucket(BucketName());
}
function GetDataFromBucket($bucket_name, $database_ip, $account, $password){
	$result = "";
	$count = 0;
	$cluster = new \Couchbase\Cluster($database_ip);
	// $cluster->authenticateAs($account,$password);
	$cluster->authenticateAs($account,$password);
	// $cluster->operation_timeout = 2500000;
	// var_dump($bucket_name);
	$bucket = $cluster->openBucket($bucket_name);
	$data_array = array();
	$data_name = array();

	date_default_timezone_set('Asia/Hong_Kong');
	$date = date('m_d_Y_h_i_s_a', time());

	$query = CouchbaseN1qlQuery::fromString("select count(data) as count from ".$bucket_name." as data");
	try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		if($json["rows"]!=null){
			// var_dump($json["rows"]);
			if($json["rows"][0]!=null){
				if($json["rows"][0]["count"]!=null){
					$count = $json["rows"][0]["count"];
				}
			}
		}
	} catch (\Exception $e) {
		// echo "fail";
	}


	$zip = new ZipArchive();
	$DelFilePath=$date.".zip";
	if(file_exists(dirname(dirname(__FILE__))."/backup/".$DelFilePath)) {
		unlink (dirname(dirname(__FILE__))."/backup/".$DelFilePath);
	}
	$result=dirname(dirname(__FILE__))."/backup/".$DelFilePath;
	if ($zip->open(dirname(dirname(__FILE__))."/backup/".$DelFilePath, ZIPARCHIVE::CREATE) != TRUE) {
	        // die ("Could not open archive");
					$result="fail";
	}

	for($offset = 0; $offset < $count; $offset++){
		$query = CouchbaseN1qlQuery::fromString("select META(data).id, data from ".$bucket_name." as data limit 1 offset ".$offset);
		try {
			$rows = $bucket->query($query);
			$json = json_decode(json_encode($rows),true);
			if($json["rows"]!=null){
				if($json["rows"][0]!=null){
					// $result = json_encode($json["rows"][0]);
					$data_id = $json["rows"][0]["id"];
					$data = json_encode($json["rows"][0]);

					array_push($data_name, $data_id);
					array_push($data_array, $data);
					try{
						$file = fopen(dirname(dirname(__FILE__))."/backup/".$data_id.".txt","w");
						fwrite($file, $data);
						fclose($file);
						$zip->addFile(dirname(dirname(__FILE__))."/backup/".$data_id.".txt",$data_id.".txt");
						// $result = dirname(dirname(__FILE__))."/backup/".$DelFilePath;
						$result=WebsiteLink()."backup/".$DelFilePath;
					} catch (\Exception $e) {
						$result='fail';
						// echo "fail";
					}
				}
			}
		} catch (\Exception $e) {
			$result='fail';
			// echo "fail";
		}
	}
	$zip->close();

	for($offset = 0; $offset < count($data_name); $offset++){
		if(file_exists(dirname(dirname(__FILE__))."/backup/".$data_name[$offset].".txt")) {
			unlink (dirname(dirname(__FILE__))."/backup/".$data_name[$offset].".txt");
		}
	}
	return $result;// = json_encode($data_array);
}
function ImportData($bucket_name, $database_ip, $account, $password, $upload_data){
	$result = "";
	$count = 0;
	$cluster = new \Couchbase\Cluster($database_ip);
	// $cluster->authenticateAs($account,$password);
	$cluster->authenticateAs($account,$password);
	// $cluster->operation_timeout = 2500000;
	// var_dump($bucket_name);
	$bucket = $cluster->openBucket($bucket_name);

	$document_id = json_decode($upload_data,true)["id"];
	$data = json_encode(json_decode($upload_data,true)["data"]);

	$query = CouchbaseN1qlQuery::fromString("UPSERT INTO ".$bucket_name." (KEY, VALUE) VALUES (\"".$document_id."\",".$data.") RETURNING * ;");
	//var_dump("UPSERT INTO Dev (KEY, VALUE) VALUES (\"".$document_id."\",".json_encode($user_data).") RETURNING * ;");
	try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		if(array_key_exists("rows",$json) && $json["rows"]!=null){
			if($json["rows"][0]!=null){
				if(array_key_exists($bucket_name,$json["rows"][0]) && $json["rows"][0][$bucket_name]!=null){
					$result = $json["rows"][0][$bucket_name];
				}
			}
		}
	 // var_dump($json);
	} catch (\Exception $e) {
	}
	return $result;
}


function NewId($item)
{
  $new_id = 0;

  $bucket = Bucket();

  $query = CouchbaseN1qlQuery::fromString("select Id from " . BucketName() . " where META(" . BucketName() . ").id = '".$item."IdList'");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]["Id"] != null) {
          $new_id = (int) $json["rows"][0]["Id"];
        }
      }
    }
  } catch (\Exception $e) { }
  $new_id += 1;
  $data_array = array("Id" => (string) ((int) $new_id));
  $query2 = CouchbaseN1qlQuery::fromString("UPSERT INTO " . BucketName() . " (KEY, VALUE) VALUES (\"".$item."IdList\"," . json_encode($data_array) . ") RETURNING * ;");
  $bucket->query($query2);
  return $new_id;
}

function UploadImage($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  $temp_data = IndexDataMerge($temp_data);
  $file_name = "";

  if (isset($temp_data['upload_data'])) {
    $file_name = "image_upload_" . NewId('ImageUpload') . '.' . $temp_data['upload_file_type'];
    $file = fopen(dirname(dirname(dirname(__FILE__))) . "/Media/" . $file_name, "w");
    $data = explode(',', $temp_data['upload_data']);
    fwrite($file, base64_decode($data[1]));
    fclose($file);
    unset($temp_data['upload_data']);
    unset($temp_data['upload_file_type']);
    $result = array("result" => "success", "data" => $file_name);
  }
  return json_encode($result);
}
?>
