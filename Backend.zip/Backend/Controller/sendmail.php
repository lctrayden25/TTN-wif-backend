<?php
header("Access-Control-Allow-Origin: *");
header('Content-type: text/plain; charset=utf-8');
ini_set("display_errors","On");
error_reporting(E_ALL);
date_default_timezone_set("Asia/Hong_Kong");
require 'src/PHPMailer.php';
require 'src/SMTP.php';
require 'src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
// function SendEmail($target_email, $verify_key){
//   // echo "start";
//   $mail = new PHPMailer;                              // Passing `true` enables exceptions
//   // echo "new";
//   try {
//     $html_string = '<html><body style="width:800px">
//       <div width="100%" style="height:50px"></div><div width="80%" style="margin-left:10%; margin-right:10%;">
//         請在你的裝置上輸入以下驗證碼：<br>
//         <h1>{{verify_key}}</h1>
//       </div></body></html>';
//       $html_string = str_replace("{{email}}",$target_email,$html_string);
//       $html_string = str_replace("{{verify_key}}",$verify_key,$html_string);

//       //Server settings
//       $mail->SMTPDebug = 0;                                 // Enable verbose debug output
//       $mail->isSMTP();                                      // Set mailer to use SMTP
//       $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
//       $mail->SMTPAuth = true;                               // Enable SMTP authentication
//       $mail->Username = 'edwin@innpression.com';                 // SMTP username
//       $mail->Password = 'Edwin@Innpression';                           // SMTP password
//       $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
//       $mail->Port = 587;                                    // TCP port to connect to

//       //Recipients
//       $mail->setFrom('edwin@innpression.com', 'Pret-A-Dress');
//       $mail->addAddress($target_email);

//       //Content
//       $mail->isHTML(true);                                  // Set email format to HTML
//       $mail->Subject = "Pret-A-Dress Email Validate";
//       $mail->Body = $html_string;

//       $mail->send();
//   } catch (Exception $e) {
//   }
//   // echo "end";
// }
// function SendNewPassword($target_email, $new_password){
//   // echo "start";
//   $mail = new PHPMailer;                              // Passing `true` enables exceptions
//   // echo "new";
//   try {
//     $html_string = '<html><body style="width:800px">
//       <div width="100%" style="height:50px"></div><div width="80%" style="margin-left:10%; margin-right:10%;">
//         請在你的新密碼：<br>
//         <h1>{{new_password}}</h1>
//       </div></body></html>';
//       $html_string = str_replace("{{email}}",$target_email,$html_string);
//       $html_string = str_replace("{{new_password}}",$new_password,$html_string);

//       //Server settings
//       $mail->SMTPDebug = 0;                                 // Enable verbose debug output
//       $mail->isSMTP();                                      // Set mailer to use SMTP
//       $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
//       $mail->SMTPAuth = true;                               // Enable SMTP authentication
//       $mail->Username = 'edwin@innpression.com';                 // SMTP username
//       $mail->Password = 'Edwin@Innpression';                           // SMTP password
//       $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
//       $mail->Port = 587;                                    // TCP port to connect to

//       //Recipients
//       $mail->setFrom('edwin@innpression.com', 'Pret-A-Dress');
//       $mail->addAddress($target_email);

//       //Content
//       $mail->isHTML(true);                                  // Set email format to HTML
//       $mail->Subject = "Pret-A-Dress Email Validate";
//       $mail->Body = $html_string;

//       $mail->send();
//   } catch (Exception $e) {
//   }
//   // echo "end";
// }
// function SendResetPasswordEmail($target_email,$key){
//   // echo "start";
//   $mail = new PHPMailer;                              // Passing `true` enables exceptions
//   // echo "new";
//   try {
//     $html_string = '<html><body style="width:800px">
//       <div width="100%" style="height:50px"></div><div width="80%" style="margin-left:10%; margin-right:10%;">
//         請點擊以下連結更新密碼<br>
//         <a href="http://167.99.69.151/reset_password.php?email={{email}}&key={{key}}" target="_top">更新密碼</a>。
//       </div></body></html>';
//       $html_string = str_replace("{{email}}",$target_email,$html_string);
//       $html_string = str_replace("{{key}}",$key,$html_string);

//       //Server settings
//       $mail->SMTPDebug = 0;                                 // Enable verbose debug output
//       $mail->isSMTP();                                      // Set mailer to use SMTP
//       $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
//       $mail->SMTPAuth = true;                               // Enable SMTP authentication
//       $mail->Username = 'edwin@innpression.com';                 // SMTP username
//       $mail->Password = 'Edwin@Innpression';                           // SMTP password
//       $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
//       $mail->Port = 587;                                    // TCP port to connect to

//       $mail->setFrom('edwin@innpression.com', 'Pret-A-Dress');
//       $mail->addAddress($target_email);
//       // $mail->addReplyTo('info@example.com', 'Information');
//       // $mail->addCC('cc@example.com');
//       // $mail->addBCC('bcc@example.com');

//       //Attachments
//       // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
//       // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

//       //Content
//       $mail->isHTML(true);                                  // Set email format to HTML
//       $mail->Subject = "Pret-A-Dress Password Reset";
//       $mail->Body = $html_string;
//       // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

//       $mail->send();
//       // echo 'Message has been sent';
//   } catch (Exception $e) {
//       // echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
//   }
//   // echo "end";
// }
// // function SendResetPasswordEmail($target_email,$key){
// //   // echo "start";
// //   $mail = new PHPMailer;                              // Passing `true` enables exceptions
// //   // echo "new";
// //   try {
// //     $html_string = '<html><body style="width:800px">
// //       <div width="100%" style="height:50px"></div><div width="80%" style="margin-left:10%; margin-right:10%;">
// //         請點擊以下連結更新密碼<br>
// //         <a href="https://www.innpressionhost.com/files/Ordergram/reset_password.php?email={{email}}&key={{key}}" target="_top">更新密碼</a>。
// //       </div></body></html>';
// //       $html_string = str_replace("{{email}}",$target_email,$html_string);
// //       $html_string = str_replace("{{key}}",$key,$html_string);
// //
// //       //Server settings
// //       $mail->SMTPDebug = 2;                                 // Enable verbose debug output
// //       $mail->isSMTP();                                      // Set mailer to use SMTP
// //       $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
// //       $mail->SMTPAuth = true;                               // Enable SMTP authentication
// //       $mail->Username = 'edwin@innpression.com';                 // SMTP username
// //       $mail->Password = 'Edwin@Innpression';                           // SMTP password
// //       $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
// //       $mail->Port = 587;                                    // TCP port to connect to
// //
// //       //Recipients
// //       $mail->setFrom('edwin@innpression.com', 'Ordergram');
// //       $mail->addAddress($target_email);               // Name is optional
// //       // $mail->addReplyTo('info@example.com', 'Information');
// //       // $mail->addCC('cc@example.com');
// //       // $mail->addBCC('bcc@example.com');
// //
// //       //Attachments
// //       // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
// //       // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
// //
// //       //Content
// //       $mail->isHTML(true);                                  // Set email format to HTML
// //       $mail->Subject = "Ordergram Password Reset";
// //       $mail->Body = $html_string;
// //       // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
// //
// //       $mail->send();
// //       // echo 'Message has been sent';
// //   } catch (Exception $e) {
// //       // echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
// //   }
// //   // echo "end";
// // }
?>
