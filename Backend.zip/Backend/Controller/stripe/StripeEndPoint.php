<?php
header("Access-Control-Allow-Origin: *");
ini_set("display_errors","On");
error_reporting(E_ALL);
date_default_timezone_set("Asia/Hong_Kong");
require_once('init.php');
require_once("../Controller/order_controller.php");
require_once("../Controller/app_admin_controller.php");


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // fetch RAW input
    $json = file_get_contents('php://input');

    // decode json
    $get_data = json_decode($json,true);

    if($get_data['data']['object']['status'] == "paid"){
        $all_apps_data = json_decode(GetAllAdmin(),true);
          for($i = 0; $i < count($all_apps_data);$i++){
            if($all_apps_data[$i]['subscribe_plan_key'] == $get_data['data']['object']["subscription"]){
              if($get_data['data']['object']['subtotal']==30000){
                ChangePlanToPremium($all_apps_data[$i]['application_key']);
                $target_plan = 'premium_plan';
              }else if($get_data['data']['object']['subtotal']==6500){
                $target_plan = 'basic_plan';
                ChangePlanToBasic($all_apps_data[$i]['application_key']);
              }
              $price = intval($get_data['data']['object']['subtotal'])/100;
              $sent_data = array('application_key'=> $all_apps_data[$i]['application_key'],'target_plan'=>$target_plan,'payment_price'=>$price,'invoice_detail'=>$get_data['data']['object']);
              CreateAdminPlanPayment(json_encode($sent_data));

            }
          }
    }

}
?>
