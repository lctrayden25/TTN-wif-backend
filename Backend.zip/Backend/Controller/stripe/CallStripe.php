<?php
header("Access-Control-Allow-Origin: *");
ini_set("display_errors","On");
error_reporting(E_ALL);
date_default_timezone_set("Asia/Hong_Kong");
require_once('init.php');
// require_once("../Controller/order_controller.php");
// require_once("../Controller/app_admin_controller.php");

// if (isset($_POST['order_id'], $_POST['price'], $_POST['shop_name'])) {
//   CallStripe($_POST['order_id'], $_POST['price'], $_POST['shop_name']);
// }

// if (isset($_POST['call_testing'])) {
//   CallStripe($_POST['call_testing']);
// }

// if(array_key_exists('card_number',$_POST) && array_key_exists('exp_month',$_POST) && array_key_exists('exp_year',$_POST) && array_key_exists('cvc',$_POST)&& array_key_exists('admin_price',$_POST)){
//   CallAdminStripe($_POST['card_number'],$_POST['exp_month'],$_POST['exp_year'],$_POST['cvc'],$_POST['admin_price']);
// }

// if(array_key_exists('apple_google_token',$_POST) && array_key_exists('apple_google_price',$_POST) && array_key_exists('apps_key',$_POST) ){
//   CallApplePay($_POST['apple_google_token'],$_POST['apple_google_price'],$_POST['apps_key']);
// }
//
//
// if(array_key_exists('alipay_src_id',$_POST) && array_key_exists('order_id',$_POST) && array_key_exists('call_alipay_price',$_POST)&& array_key_exists('apps_key',$_POST) ){
//   AlipayPay($_POST['alipay_src_id'],$_POST['order_id'],$_POST['call_alipay_price'],$_POST['apps_key']);
// }
//
// if(array_key_exists('card_number',$_POST) && array_key_exists('exp_month',$_POST) && array_key_exists('exp_year',$_POST) && array_key_exists('cvc',$_POST)&& array_key_exists('plan',$_POST)&& array_key_exists('apps_key',$_POST)){
//   SubscribePlan($_POST['card_number'],$_POST['exp_month'],$_POST['exp_year'],$_POST['cvc'],$_POST['plan'],$_POST['apps_key']);
// }
//
// if(array_key_exists('cancel_plan_apps_key',$_POST)){
//   CancelPlanToFree($_POST['cancel_plan_apps_key']);
// }


// function CreateBasicPlan(){
//   \Stripe\Stripe::setApiKey("sk_live_P3vQSFvLLFe9qUSqtNhl068w");
//
//   \Stripe\Plan::create([
//     "amount" => 6500,
//     "interval" => "month",
//     "product" => [
//       "name" => "Exhabit Basic Plan"
//     ],
//     "currency" => "hkd",
//     "id" => "exhabit-basic"
//   ]);
//
//   $result = \Stripe\Plan::retrieve('exhabit-basic');
//
//   return json_encode($result);
// }
//
// function CreatePremiumPlan(){
//   \Stripe\Stripe::setApiKey("sk_live_P3vQSFvLLFe9qUSqtNhl068w");
//
//   \Stripe\Plan::create([
//     "amount" => 30000,
//     "interval" => "month",
//     "product" => [
//       "name" => "Exhabit Premium Plan"
//     ],
//     "currency" => "hkd",
//     "id" => "exhabit-premium"
//   ]);
//
//   $result = \Stripe\Plan::retrieve('exhabit-premium');
//
//   return json_encode($result);
// }
//
// function SubscribePlan($number,$mm,$yy,$cvc,$plan,$key){
//
//   CancelPlan($key);
//
//   \Stripe\Stripe::setApiKey("sk_live_P3vQSFvLLFe9qUSqtNhl068w");
//
//   try {
//   $result = \Stripe\Plan::retrieve('exhabit-premium');
//   // echo json_encode($result);
//
//   $token = \Stripe\Token::create([
//     "card" => [
//       "number" => $number,
//       "exp_month" => $mm,
//       "exp_year" => $yy,
//       "cvc" => $cvc
//     ]
//   ]);
//
//   $cust = \Stripe\Customer::create([
//     "description" => "Exhabit Admin User",
//     "source" => $token['id']
//   ]);
//
//   if ($plan == 'premium_plan'){
//     $sub = \Stripe\Subscription::create([
//       "customer" => $cust['id'],
//       "items" => [
//         [
//           "plan" => "exhabit-premium",
//         ],
//       ]
//     ]);
//   }else if($plan == 'basic_plan'){
//     $sub = \Stripe\Subscription::create([
//       "customer" => $cust['id'],
//       "items" => [
//         [
//           "plan" => "exhabit-basic",
//         ],
//       ]
//     ]);
//   }else{
//     echo 'error';
//   }
//     if($sub['status'] == 'active'){
//       //!!sendemail you just join plan .id
//       UpdateAccountAddPlan($key,$sub['id']);
//       $invoice = \Stripe\Invoice::retrieve($sub['latest_invoice']);
//
//       echo json_encode($invoice);
//     }
//
//   } catch(\Stripe\Error\Card $e) {
//     // Since it's a decline, \Stripe\Error\Card will be caught
//     $body = $e->getJsonBody();
//     $err  = $body['error'];
//
//     echo json_encode($err);
//
//   } catch (\Stripe\Error\RateLimit $e) {
//     // Too many requests made to the API too quickly
//   } catch(\Stripe\Error\InvalidRequest $e) {
//     // Since it's a decline, \Stripe\Error\Card will be caught
//     $body = $e->getJsonBody();
//     $err  = $body['error'];
//
//     echo json_encode($err); //.code = resource_missing
//   } catch (\Stripe\Error\Authentication $e) {
//     // Authentication with Stripe's API failed
//     // (maybe you changed API keys recently)
//   } catch (\Stripe\Error\ApiConnection $e) {
//     // Network communication with Stripe failed
//   } catch (\Stripe\Error\Base $e) {
//     // Display a very generic error to the user, and maybe send
//     // yourself an email
//   } catch (Exception $e) {
//     // Something else happened, completely unrelated to Stripe
//   }
//
// }
//
// function CancelPlan($key){
//   $store_data = json_decode(AdminGetAppsData($key),true)['data'];
//   if($store_data['subscribe_plan_key'] != ''){
//     CancelPlanByStripeKey($key,$store_data['subscribe_plan_key']);
//   }
// }
//
// function CancelPlanToFree($key){
//   $store_data = json_decode(AdminGetAppsData($key),true)['data'];
//   if($store_data['subscribe_plan_key'] != ''){
//     CancelPlanByStripeKey($key,$store_data['subscribe_plan_key']);
//   }
//   ChangePlanToFree($key);
//
// }
//
// function CancelPlanByStripeKey($app_key,$key){
//
//     \Stripe\Stripe::setApiKey("sk_live_P3vQSFvLLFe9qUSqtNhl068w");
//
//     try {
//       $sub = \Stripe\Subscription::retrieve($key);
//       $sub->cancel();
//
//       if($sub['status'] == "canceled"){
//         //!!sendemail you just stop plan .id
//         UpdateAccountCancelPlan($app_key);
//       }
//     } catch(\Stripe\Error\Card $e) {
//       // Since it's a decline, \Stripe\Error\Card will be caught
//       $body = $e->getJsonBody();
//       $err  = $body['error'];
//
//       echo json_encode($err);
//
//     } catch (\Stripe\Error\RateLimit $e) {
//       // Too many requests made to the API too quickly
//     } catch(\Stripe\Error\InvalidRequest $e) {
//       // Since it's a decline, \Stripe\Error\Card will be caught
//       $body = $e->getJsonBody();
//       $err  = $body['error'];
//
//       echo json_encode($err); //.code = resource_missing
//     } catch (\Stripe\Error\Authentication $e) {
//       // Authentication with Stripe's API failed
//       // (maybe you changed API keys recently)
//     } catch (\Stripe\Error\ApiConnection $e) {
//       // Network communication with Stripe failed
//     } catch (\Stripe\Error\Base $e) {
//       // Display a very generic error to the user, and maybe send
//       // yourself an email
//     } catch (Exception $e) {
//       // Something else happened, completely unrelated to Stripe
//     }
// }
// function CallApplePay($token,$price,$key){
//   $stripe_key = 'sk_live_P3vQSFvLLFe9qUSqtNhl068w';
//   $store_data = json_decode(AdminGetAppsData($key),true)['data'];
//   if($store_data['stripe_secret_key']!= ''){
//     $stripe_key = $store_data['stripe_secret_key'];
//   }
//   //$key
//   \Stripe\Stripe::setApiKey($stripe_key);//pk_test_HrQKa5jMxqXQaTixNi65Qi33
//
//   //amount*100 already in js
//   $charge = \Stripe\Charge::create([
//   "amount" => $price,
//   "currency" => "hkd",
//   "source"=> $token
//   ]);
//
//   echo json_encode($charge);
//
// }
// function AlipayPay($src_id,$order_id,$price,$key){
//   $stripe_key = 'sk_live_P3vQSFvLLFe9qUSqtNhl068w';
//   $store_data = json_decode(AdminGetAppsData($key),true)['data'];
//   if($store_data['stripe_secret_key']!= ''){
//     $stripe_key = $store_data['stripe_secret_key'];
//   }
//   //$key
//   \Stripe\Stripe::setApiKey($stripe_key);//pk_test_HrQKa5jMxqXQaTixNi65Qi33
//
//     $charge = \Stripe\Charge::create([
//     "amount" => $price * 100,
//     "currency" => "hkd",
//     "source"=> $src_id
//   ]);
//
//     if($charge['status'] == 'succeeded'){
//       UpdateOrderAlipayData($order_id,json_encode($charge));
//     }
//
//     echo json_encode($charge);
// }

// if(array_key_exists('card_number',$_POST) && array_key_exists('exp_month',$_POST) && array_key_exists('exp_year',$_POST) && array_key_exists('cvc',$_POST) && array_key_exists('price',$_POST) && array_key_exists('dollar_type',$_POST)){
//   CallStripe($_POST['card_number'],$_POST['exp_month'],$_POST['exp_year'],$_POST['cvc'],$_POST['price'],$_POST['dollar_type']);
// }

function CreateStripeToken($in_bound_data){
  $temp_data = json_decode($in_bound_data,true);

	if(!array_key_exists('card_number',$temp_data) || !array_key_exists('exp_month',$temp_data) || !array_key_exists('exp_year',$temp_data) || !array_key_exists('cvc',$temp_data) || !array_key_exists('email',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing!"));
	}
  $stripe_key = 'sk_test_oIlOdo9nNIAArDxEx1tkW5u8';//'sk_live_V2Utqd9BpPqYcSMjZ4uMs4YY';//
  //$key
  \Stripe\Stripe::setApiKey($stripe_key);//pk_test_HrQKa5jMxqXQaTixNi65Qi33

  try {
    // echo "123";
    // Use Stripe's library to make requests...
    $token = \Stripe\Token::create([
      "card" => [
        "number" => $temp_data['card_number'],
        "exp_month" => $temp_data['exp_month'],
        "exp_year" => $temp_data['exp_year'],
        "cvc" => $temp_data['cvc']
      ]
    ]);

    $customer = \Stripe\Customer::create([
        'source' => $token['id'],
        'email' => $temp_data['email'],
    ]);

    // echo json_encode($charge);
		// return json_encode(array("result"=>"success","data"=>$token));
		return json_encode(array("result"=>"success","data"=>$customer));
  // echo $token['id'];
  } catch(\Stripe\Error\Card $e) {
    // Since it's a decline, \Stripe\Error\Card will be caught
    $body = $e->getJsonBody();
    $err  = $body['error'];

    // echo json_encode($err);
		return json_encode(array("result"=>"fail","data"=>$err));

  } catch (\Stripe\Error\RateLimit $e) {
    $body = $e->getJsonBody();
    $err  = $body['error'];

    // echo json_encode($err);
		return json_encode(array("result"=>"fail","data"=>$err));
    // Too many requests made to the API too quickly
  } catch (\Stripe\Error\InvalidRequest $e) {
    $body = $e->getJsonBody();
    $err  = $body['error'];

    // echo json_encode($err);
		return json_encode(array("result"=>"fail","data"=>$err));
    // Invalid parameters were supplied to Stripe's API
  } catch (\Stripe\Error\Authentication $e) {
    $body = $e->getJsonBody();
    $err  = $body['error'];

    // echo json_encode($err);
		return json_encode(array("result"=>"fail","data"=>$err));
    // Authentication with Stripe's API failed
    // (maybe you changed API keys recently)
  } catch (\Stripe\Error\ApiConnection $e) {
    $body = $e->getJsonBody();
    $err  = $body['error'];

    // echo json_encode($err);
		return json_encode(array("result"=>"fail","data"=>$err));
    // Network communication with Stripe failed
  } catch (\Stripe\Error\Base $e) {
    $body = $e->getJsonBody();
    $err  = $body['error'];

    // echo json_encode($err);
		return json_encode(array("result"=>"fail","data"=>$err));
    // Display a very generic error to the user, and maybe send
    // yourself an email
  } catch (Exception $e) {
    $body = $e->getJsonBody();
    $err  = $body['error'];

    // echo json_encode($err);
		return json_encode(array("result"=>"fail","data"=>$err));
    // Something else happened, completely unrelated to Stripe
  }
}

function CallStripe($in_bound_data){
  // return $in_bound_data;
  $temp_data = json_decode($in_bound_data,true);

  // return json_encode($temp_data);
	if(!array_key_exists('price',$temp_data) || !array_key_exists('token',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing!"));
	}
  $stripe_key = 'sk_test_oIlOdo9nNIAArDxEx1tkW5u8';//'sk_live_V2Utqd9BpPqYcSMjZ4uMs4YY';//
  //$key
  \Stripe\Stripe::setApiKey($stripe_key);//pk_test_HrQKa5jMxqXQaTixNi65Qi33


  try {
    $price = $temp_data['price'] * 100;
    $charge = \Stripe\Charge::create([
    "amount" => $price,
    "currency" => "HKD",
    // "source"=> $temp_data['token']['id']
    "customer"=> $temp_data['token']['id']
    ]);

    // echo json_encode($charge);
		return json_encode(array("result"=>"success","data"=>$charge));
  // echo $token['id'];
  } catch(\Stripe\Error\Card $e) {
    // Since it's a decline, \Stripe\Error\Card will be caught
    $body = $e->getJsonBody();
    $err  = $body['error'];

    // echo json_encode($err);
		return json_encode(array("result"=>"fail","data"=>$err));

  } catch (\Stripe\Error\RateLimit $e) {
    $body = $e->getJsonBody();
    $err  = $body['error'];

    // echo json_encode($err);
		return json_encode(array("result"=>"fail","data"=>$err));
    // Too many requests made to the API too quickly
  } catch (\Stripe\Error\InvalidRequest $e) {
    $body = $e->getJsonBody();
    $err  = $body['error'];

    // echo json_encode($err);
		return json_encode(array("result"=>"fail","data"=>$err));
    // Invalid parameters were supplied to Stripe's API
  } catch (\Stripe\Error\Authentication $e) {
    $body = $e->getJsonBody();
    $err  = $body['error'];

    // echo json_encode($err);
		return json_encode(array("result"=>"fail","data"=>$err));
    // Authentication with Stripe's API failed
    // (maybe you changed API keys recently)
  } catch (\Stripe\Error\ApiConnection $e) {
    $body = $e->getJsonBody();
    $err  = $body['error'];

    // echo json_encode($err);
		return json_encode(array("result"=>"fail","data"=>$err));
    // Network communication with Stripe failed
  } catch (\Stripe\Error\Base $e) {
    $body = $e->getJsonBody();
    $err  = $body['error'];

    // echo json_encode($err);
		return json_encode(array("result"=>"fail","data"=>$err));
    // Display a very generic error to the user, and maybe send
    // yourself an email
  } catch (Exception $e) {
    $body = $e->getJsonBody();
    $err  = $body['error'];

    // echo json_encode($err);
		return json_encode(array("result"=>"fail","data"=>$err));
    // Something else happened, completely unrelated to Stripe
  }
}

function DirectCallStripe($in_bound_data){
  // return $in_bound_data;
  $temp_data = json_decode($in_bound_data,true);

  // return json_encode($temp_data);

	if(!array_key_exists('card_number',$temp_data) || !array_key_exists('exp_month',$temp_data) || !array_key_exists('exp_year',$temp_data) || !array_key_exists('cvc',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing!"));
	}
	if(!array_key_exists('price',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing!"));
	}
  $stripe_key = 'sk_test_oIlOdo9nNIAArDxEx1tkW5u8';//'sk_live_V2Utqd9BpPqYcSMjZ4uMs4YY';//
  //$key
  \Stripe\Stripe::setApiKey($stripe_key);//pk_test_HrQKa5jMxqXQaTixNi65Qi33


  try {
    $token = \Stripe\Token::create([
      "card" => [
        "number" => $temp_data['card_number'],
        "exp_month" => $temp_data['exp_month'],
        "exp_year" => $temp_data['exp_year'],
        "cvc" => $temp_data['cvc']
      ]
    ]);

    $price = $temp_data['price'] * 100;
    $charge = \Stripe\Charge::create([
    "amount" => $price,
    "currency" => "HKD",
    "source"=> $token['id']
    ]);

    // echo json_encode($charge);
		return json_encode(array("result"=>"success","data"=>$charge));
  // echo $token['id'];
  } catch(\Stripe\Error\Card $e) {
    // Since it's a decline, \Stripe\Error\Card will be caught
    $body = $e->getJsonBody();
    $err  = $body['error'];

    // echo json_encode($err);
		return json_encode(array("result"=>"fail","data"=>$err));

  } catch (\Stripe\Error\RateLimit $e) {
    $body = $e->getJsonBody();
    $err  = $body['error'];

    // echo json_encode($err);
		return json_encode(array("result"=>"fail","data"=>$err));
    // Too many requests made to the API too quickly
  } catch (\Stripe\Error\InvalidRequest $e) {
    $body = $e->getJsonBody();
    $err  = $body['error'];

    // echo json_encode($err);
		return json_encode(array("result"=>"fail","data"=>$err));
    // Invalid parameters were supplied to Stripe's API
  } catch (\Stripe\Error\Authentication $e) {
    $body = $e->getJsonBody();
    $err  = $body['error'];

    // echo json_encode($err);
		return json_encode(array("result"=>"fail","data"=>$err));
    // Authentication with Stripe's API failed
    // (maybe you changed API keys recently)
  } catch (\Stripe\Error\ApiConnection $e) {
    $body = $e->getJsonBody();
    $err  = $body['error'];

    // echo json_encode($err);
		return json_encode(array("result"=>"fail","data"=>$err));
    // Network communication with Stripe failed
  } catch (\Stripe\Error\Base $e) {
    $body = $e->getJsonBody();
    $err  = $body['error'];

    // echo json_encode($err);
		return json_encode(array("result"=>"fail","data"=>$err));
    // Display a very generic error to the user, and maybe send
    // yourself an email
  } catch (Exception $e) {
    $body = $e->getJsonBody();
    $err  = $body['error'];

    // echo json_encode($err);
		return json_encode(array("result"=>"fail","data"=>$err));
    // Something else happened, completely unrelated to Stripe
  }
}
?>
