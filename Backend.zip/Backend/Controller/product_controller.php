<?php
header("Access-Control-Allow-Origin: *");
ini_set("display_errors", "On");
error_reporting(E_ERROR);
date_default_timezone_set("Asia/Hong_Kong");
include_once('databasetool.php');
include_once('checker.php');
include_once('encryption.php');

// Agency ---------------------------------------------------------------------------------------------------------------- //

function ProductInit($data)
{
  if (!isset($data['id'])) {
    $data['id'] = NewId('Product');
  }
  if (!isset($data['data_type'])) {
    $data['data_type'] = "product_data";
  }

  if (!isset($data['create_date'])) {
    $data['create_date'] = GetCurrentTimeString();
  }

  if (!isset($data['active'])) {
    $data['active'] = true;
  }

  if (!isset($data['name'])) {
    $data['name'] = "";
  }

  if (!isset($data['description'])) {
    $data['description'] = "";
  }

  if (!isset($data['type'])) {
    $data['type'] = "";
  }

  if (!isset($data['price'])) {
    $data['price'] = 0;
  }

  if (!isset($data['credit'])) {
    $data['credit'] = 0;
  }

  if (!isset($data['bonus'])) {
    $data['bonus'] = 0;
  }

  if (!isset($data['attr'])) {
    $data['attr'] = Array();
  }


  if (!isset($data['inventory'])) {
    $data['inventory'] = Array();
  }


  return $data;
}

function NewProduct($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  // if(!array_key_exists("name", $temp_data) || !array_key_exists("date", $temp_data) || !array_key_exists("start_time", $temp_data) || !array_key_exists("end_time", $temp_data)){
  //   return json_encode(array("result" => "success", "data" => "missing must key"));
  // }

  $temp_data = ProductInit($temp_data);

  //N1QL
  $query = CouchbaseN1qlQuery::fromString("UPSERT INTO " . BucketName() . " as data (KEY, VALUE) VALUES (\"product_" . $temp_data['id'] . "\"," . json_encode($temp_data) . ") RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]["data"] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          return json_encode(array("result" => "success", "data" => $user_data));
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function UpdateProduct($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if (!array_key_exists('id', $temp_data)) {
    return json_encode(array("result" => "fail", "data" => "value missing"));
  }
  $update_string = "";
  
  $data = ProductInit($temp_data);

  if (isset($data['active'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " active = " . json_encode($data['active']) . " ";
  }

  if (isset($data['name'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " name = " . json_encode($data['name']) . " ";
  }

  if (isset($data['description'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " description = " . json_encode($data['description']) . " ";
  }

  if (isset($data['type'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " type = " . json_encode($data['type']) . " ";
  }

  if (isset($data['price'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " price = " . $data['price'] . " ";
  }

  if (isset($data['credit'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " credit = " . $data['credit'] . " ";
  }

  if (isset($data['bonus'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " bonus = " . $data['bonus'] . " ";
  }

  if (isset($data['attr'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " attr = " . json_encode($data['attr']) . " ";
  }

  if (isset($data['inventory'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " inventory = " . json_encode($data['inventory']) . " ";
  }

  $query = CouchbaseN1qlQuery::fromString("update " . BucketName() . " as data set " . $update_string . " where id=" . $temp_data['id'] . " and data_type='product_data' RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    // return json_encode($json);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]['data'] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          $result['data'] = $user_data;
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function UpdateProductInventory($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if (!array_key_exists('id', $temp_data)) {
    return json_encode(array("result" => "fail", "data" => "value missing"));
  }
  $update_string = "";
  
  // $data = ProductInit($temp_data);

  if (isset($temp_data['inventory'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " inventory = " . json_encode($temp_data['inventory']) . " ";
  }

  $query = CouchbaseN1qlQuery::fromString("update " . BucketName() . " as data set " . $update_string . " where id=" . $temp_data['id'] . " and data_type='product_data' RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    // return json_encode($json);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]['data'] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          $result['data'] = $user_data;
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function GetAllProduct(){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);

  $query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='product_data' order by id desc;");
  try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		$result = array("result"=>"success","data"=>[]);
		if($json["rows"]!=null){
				$result['data'] = $json["rows"];
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}

function GetProductById($in_bound_data){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);
  $temp_data = json_decode($in_bound_data,true);

	if(!array_key_exists('id',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing"));
	}

	$query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='product_data' and id=".$temp_data['id']." ;");
  try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		$result = array("result"=>"success","data"=>[]);
		if($json["rows"]!=null){
			if($json["rows"][0]!=null){
				$result['data'] = $json["rows"][0];
			}
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}

function GetProductByIdList($in_bound_data){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);
  $temp_data = json_decode($in_bound_data,true);

	if(!array_key_exists('id_list',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing"));
	}

	$query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='product_data' and id in ".$temp_data['id_list']." ;");
  try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		$result = array("result"=>"success","data"=>[]);
		if($json["rows"]!=null){
				$result['data'] = $json["rows"];
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}

?>