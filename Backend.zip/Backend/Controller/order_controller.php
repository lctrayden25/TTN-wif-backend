<?php
header("Access-Control-Allow-Origin: *");
ini_set("display_errors", "On");
error_reporting(E_ERROR);
date_default_timezone_set("Asia/Hong_Kong");
include_once('databasetool.php');
include_once('checker.php');
include_once('encryption.php');
include_once('ticket_controller.php');
include_once('redeem_controller.php');
include_once('payment_controller.php');
include_once('credit_controller.php');
include_once('coupon_controller.php');
include_once('product_controller.php');

// Agency ---------------------------------------------------------------------------------------------------------------- //

function OrderInit($data)
{
  if (!isset($data['id'])) {
    $data['id'] = NewId('Order');
  }
  if (!isset($data['data_type'])) {
    $data['data_type'] = "order_data";
  }

  if (!isset($data['create_date'])) {
    $data['create_date'] = GetCurrentTimeString();
  }

  if (!isset($data['active'])) {
    $data['active'] = true;
  }

  if (!isset($data['status'])) {
    $data['status'] = "active";
  }

  if (!isset($data['user_id'])) {
    $data['user_id'] = -1;
  }

  if (!isset($data['total'])) {
    $data['total'] = 0;
  }

  if (!isset($data['tickets'])) {
    $data['tickets'] = Array();
  }

  if (!isset($data['products'])) {
    $data['products'] = Array();
  }

  return $data;
}

function NewOrder($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  $subtotal = 0;
  $spend_credit = 0;
  $bonus = 0;
  $inventory_pass = true;
  $is_ticket = false;
  $is_purchase = false;
  $is_redeem = false;
  // $redeem_items = Array();
  $tickets = Array();
  // $purchase_items = Array();
  $items_ids = Array();

  $redeem_items_data = Array();
  $tickets_data = Array();
  $purchase_items = Array();

  $temp_data = OrderInit($temp_data);

  //check is ticket or products or redeem
  if(count($temp_data['tickets']) > 0 || count($temp_data['products']) > 0){
    for($i=0; $i<count($temp_data['tickets']); $i++){
      array_push($tickets, $temp_data['tickets'][$i]['id']);
    }
    for($i=0; $i<count($temp_data['products']); $i++){
      array_push($items_ids, $temp_data['products'][$i]['id']);
    }
  }else{
    $result = array("result" => "fail", "data" => "no items in order");
    return json_encode($result);
  }
  if(count($tickets) >0 && count($items_ids) >0){
    $result = array("result" => "fail", "data" => "multiple type purchase not able");
    return json_encode($result);
  }
  
  $event_return = json_decode(GetEventByIdList(json_encode(array("id_list"=>$tickets))),true);
  if($event_return['result'] == "success"){
    $tickets_data = $event_return["data"];
    if(count($tickets_data) > 0){
      $is_ticket = true;
    }
  }
  
  $product_return = json_decode(GetProductByIdList(json_encode(array("id_list"=>$items_ids))),true);
  if($product_return['result'] == "success"){
    $temp_products = $product_return["data"];
    for($x=0; $x<count($temp_products); $x++){
      if($temp_products[$x]['price'] > 0){
        array_push($purchase_items, $temp_products[$x]);
      }else if($temp_products[$x]['credit'] > 0){
        array_push($redeem_items_data, $temp_products[$x]);
      }
    }
  }

  if(count($purchase_items) > 0){
    $is_purchase = true;
  }

  if(count($redeem_items_data) > 0){
    $is_redeem = true;
  }

  if(($is_ticket && !$is_purchase && !$is_redeem) || (!$is_ticket && !$is_purchase && $is_redeem) || (!$is_ticket && $is_purchase && !$is_redeem)){

  }else{
    $result = array("result" => "fail", "data" => "multiple type purchase not able");
    return json_encode($result);
  }

  //check inventory
  if($is_ticket){
    for($a=0; $a<count($temp_data['tickets']); $a++){
      for($b=0; $b<count($tickets_data); $b++){
        if($temp_data['tickets'][$a]['id'] == $tickets_data[$b]['id']){
          $event_count_return = json_decode(GetTicketsOfEvents(json_encode(array("event_id"=>$temp_data['tickets'][$a]['id']))),true);
          if($event_count_return['result'] == "success"){
            if((intval($event_count_return['data']) + intval($temp_data['tickets'][$a]['amount'])) > intval($tickets_data[$b]['capacity'])){
              $result = array("result" => "fail", "data" => "out of stock");
              return json_encode($result);
            }else{
              if(intval($tickets_data[$b]['ticket_price']) > 0){
                $subtotal += (intval($temp_data['tickets'][$a]['amount']) * intval($tickets_data[$b]['ticket_price']));
                if(intval($tickets_data[$b]['bonus']) > 0){
                  $bonus += (intval($temp_data['tickets'][$a]['amount']) * intval($tickets_data[$b]['bonus']));
                }
              }
              if(intval($tickets_data[$b]['credit']) > 0){
                $spend_credit += (intval($temp_data['tickets'][$a]['amount']) * intval($tickets_data[$b]['credit']));
              }
            }
          }
        }
      }
    }
  }else{
    if($is_purchase){
      for($a=0; $a<count($temp_data['products']); $a++){
        for($b=0; $b<count($purchase_items); $b++){
          if($temp_data['products'][$a]['id'] == $purchase_items[$b]['id']){
            if(array_key_exists($temp_data['products'][$a]['attr'], $purchase_items[$b]['inventory'])){
              if(intval($purchase_items[$b]['inventory'][$temp_data['products'][$a]['attr']]) < intval($temp_data['products'][$a]['amount'])){
                $result = array("result" => "fail", "data" => "out of stock");
                return json_encode($result);
              }else{
                if(intval($purchase_items[$b]['price']) > 0){
                  $subtotal += (intval($temp_data['products'][$a]['amount']) * intval($purchase_items[$b]['price']));
                  if(intval($purchase_items[$b]['bonus']) > 0){
                    $bonus += (intval($temp_data['products'][$a]['amount']) * intval($purchase_items[$b]['bonus']));
                  }
                }
              }
            }
          }
        }
      }
    }else{
      if($is_redeem){
        for($a=0; $a<count($temp_data['products']); $a++){
          for($b=0; $b<count($redeem_items_data); $b++){
            if($temp_data['products'][$a]['id'] == $redeem_items_data[$b]['id']){
              if(array_key_exists($temp_data['products'][$a]['attr'], $redeem_items_data[$b]['inventory'])){
                if(intval($redeem_items_data[$b]['inventory'][$temp_data['products'][$a]['attr']]) < intval($temp_data['products'][$a]['amount'])){
                  $result = array("result" => "fail", "data" => "out of stock");
                  return json_encode($result);
                }else{
                  if(intval($redeem_items_data[$b]['credit']) > 0){
                    $spend_credit += (intval($temp_data['products'][$a]['amount']) * intval($redeem_items_data[$b]['credit']));
                  }
                }
  
              }
            }
          }
        }
      }
    }
  }

  //check coupon
  $has_coupon = false;
  $coupon_data = null;
  $temp_data['original_price'] = $subtotal;
  $temp_data['spent_credit'] = $spend_credit;
  if(array_key_exists('coupon', $temp_data) && $subtotal > 0){
    $coupon_return = json_decode(GetCouponByCode(json_encode(array("code"=>$temp_data['coupon']))),true);
    if($coupon_return['result'] == "success"){
      $has_coupon = true;
      $coupon_data = $coupon_data['data'];
      $temp_data['coupon_data'] = $coupon_data;
      if($coupon_data['type'] = "percentage"){
        $subtotal = $subtotal * ( intval($coupon_data['amount']) / 100 );
      }else if($coupon_data['type'] = "fix"){
        $subtotal = $subtotal - intval($coupon_data['amount']);
      }
    }
  }

  if($subtotal < 0){
    $subtotal = 0;
  }

  $temp_data['final_price'] = $subtotal;

  //check payment
  //if purchase
  if($is_ticket || $is_purchase){
    if($subtotal >0){
      $payment_return = json_decode(NewPayment(json_encode(array("card_number"=>$temp_data['card_number'],"cvc"=>$temp_data['cvc'],"exp_year"=>$temp_data['exp_year'],"exp_month"=>$temp_data['exp_month'],"amount"=>$subtotal))),true);
      if($payment_return['result'] == "success"){
        $temp_data['payment_data'] = $payment_return['data'];
      }else{
        $result = array("result" => "fail", "data" => $payment_return['data']);
        return json_encode($result);
      }
    }
  }else{
    //if credit
    //get credit
    //use credit
    if($is_redeem){
      if($spend_credit > 0){
        $user_credit_return = json_decode(GetCreditOfUser(json_encode(array("id"=>$temp_data['user_id']))),true);
        if($user_credit_return['result'] == "success"){
          $credit_total = $user_credit_return['data'];
          if($credit_total < $spend_credit){
            $result = array("result" => "fail", "data" => "credit not enough");
            return json_encode($result);
          }else{
            $bonus_return = json_decode(UseCredit(json_encode(array("user_id"=>$temp_data['user_id'], "amount"->$spend_credit))),true);
            if($bonus_return['result'] != "success"){
            }else{
              $result = array("result" => "fail", "data" => "credit using error");
              return json_encode($result);
            }
          }
        }else{
          $result = array("result" => "fail", "data" => $user_credit_return['data']);
          return json_encode($result);
        }
      }
    }else{
      $result = array("result" => "fail", "data" => "data error will pay credit");
      return json_encode($result);
    }
  }

  //check add credit
  if($bonus > 0){
    $bonus_return = json_decode(AddCredit(json_encode(array("user_id"=>$temp_data['user_id'], "amount"->$bonus))),true);
    if($bonus_return['result'] != "success"){
      //return fail
      $temp_data["bonus_fail_to_add"] = $bonus;
    }
  }

  $error_logs = Array();

  //remove inventory
  //make ticket and redeem
  if($is_ticket){
    for($a=0; $a<count($temp_data['tickets']); $a++){
      for($b=0; $b<count($tickets_data); $b++){
        if($temp_data['tickets'][$a]['id'] == $tickets_data[$b]['id']){
          //gen ticket
          for($n=0; $n<count($temp_data['tickets'][$a]['amount']); $n++){
            $ticket_return = json_decode(NewTicket(json_encode(array("user_id"=>$temp_data['user_id'], "order_id"=>$temp_data['id'], "event_id"->$temp_data['tickets'][$a]['id']))),true);
            if($ticket_return['result'] == "success"){
            }else{
              array_push($error_logs, array("data"=>"ticket","user_id"=>$temp_data['user_id'], "order_id"=>$temp_data['id'], "event_id"->$temp_data['tickets'][$a]['id']));
            }
          }
        }
      }
    }
  }else{
    if($is_purchase){
      for($a=0; $a<count($temp_data['products']); $a++){
        for($b=0; $b<count($purchase_items); $b++){
          if($temp_data['products'][$a]['id'] == $purchase_items[$b]['id']){
            if(array_key_exists($temp_data['products'][$a]['attr'], $purchase_items[$b]['inventory'])){
              //update inventory
                $purchase_items[$b]['inventory'][$temp_data['products'][$a]['attr']] = ($purchase_items[$b]['inventory'][$temp_data['products'][$a]['attr']] - $temp_data['products'][$a]['amount']);
                $inventory_return = json_decode(UpdateProductInventory(json_encode(array("id"=>$purchase_items[$b]['id'], "inventory"=>$purchase_items[$b]['inventory']))),true);
                if($inventory_return['result'] == "success"){
                }else{
                  array_push($error_logs, array("data"=>"purchase_inventory", "products"->$temp_data['products'][$a]));
                }
            }
          }
        }
      }
    }else{
      if($is_redeem){
        for($a=0; $a<count($temp_data['products']); $a++){
          for($b=0; $b<count($redeem_items_data); $b++){
            if($temp_data['products'][$a]['id'] == $redeem_items_data[$b]['id']){
              if(array_key_exists($temp_data['products'][$a]['attr'], $redeem_items_data[$b]['inventory'])){
                //update inventory and gen redeem
                $redeem_items_data[$b]['inventory'][$temp_data['products'][$a]['attr']] = ($redeem_items_data[$b]['inventory'][$temp_data['products'][$a]['attr']] - $temp_data['products'][$a]['amount']);
                $inventory_return = json_decode(UpdateProductInventory(json_encode(array("id"=>$redeem_items_data[$b]['id'], "inventory"=>$redeem_items_data[$b]['inventory']))),true);
                if($inventory_return['result'] == "success"){
                }else{
                  array_push($error_logs, array("data"=>"redeem_inventory", "products"->$temp_data['products'][$a]));
                }

                $redeem_return = json_decode(NewRedeem(json_encode(array("user_id"=>$temp_data['user_id'], "order_id"=>$temp_data['id'], "products"->$temp_data['products'][$a]))),true);
                if($redeem_return['result'] == "success"){
                }else{
                  array_push($error_logs, array("data"=>"gen_redeem","user_id"=>$temp_data['user_id'], "order_id"=>$temp_data['id'], "products"->$temp_data['products'][$a]));
                }
              }
            }
          }
        }
      }
    }
  }

  if(count($error_logs) > 0){
    $temp_data['error_log'] = $error_logs;
  }

  //update coupon
  //update if any limited coupon confirm

  //N1QL
  $query = CouchbaseN1qlQuery::fromString("UPSERT INTO " . BucketName() . " as data (KEY, VALUE) VALUES (\"order_" . $temp_data['id'] . "\"," . json_encode($temp_data) . ") RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]["data"] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          return json_encode(array("result" => "success", "data" => $user_data));
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function UpdateOrder($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if (!array_key_exists('id', $temp_data)) {
    return json_encode(array("result" => "fail", "data" => "value missing"));
  }
  $update_string = "";
  
  $data = UserInit($temp_data);

  if (isset($data['active'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " active = " . json_encode($data['active']) . " ";
  }

  $query = CouchbaseN1qlQuery::fromString("update " . BucketName() . " as data set " . $update_string . " where id=" . $temp_data['id'] . " and data_type='order_data' RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    // return json_encode($json);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]['data'] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          $result['data'] = $user_data;
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function GetAllOrder(){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);

  $query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='order_data' order by id desc;");
  try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		$result = array("result"=>"success","data"=>[]);
		if($json["rows"]!=null){
				$result['data'] = $json["rows"];
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}

function GetOrderById($in_bound_data){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);
  $temp_data = json_decode($in_bound_data,true);

	if(!array_key_exists('id',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing"));
	}

	$query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='order_data' and id=".$temp_data['id']." ;");
  try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		$result = array("result"=>"success","data"=>[]);
		if($json["rows"]!=null){
			if($json["rows"][0]!=null){
				$result['data'] = $json["rows"][0];
			}
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}

function GetOrderByOfUser($in_bound_data){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);
  $temp_data = json_decode($in_bound_data,true);

	if(!array_key_exists('id',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing"));
	}

	$query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='order_data' and id=".$temp_data['id']." ;");
  try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		$result = array("result"=>"success","data"=>[]);
		if($json["rows"]!=null){
				$result['data'] = $json["rows"];
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}

?>