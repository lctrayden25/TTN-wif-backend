<?php
header("Access-Control-Allow-Origin: *");
ini_set("display_errors", "On");
error_reporting(E_ERROR);
date_default_timezone_set("Asia/Hong_Kong");
include_once('databasetool.php');
include_once('checker.php');
include_once('encryption.php');

// Agency ---------------------------------------------------------------------------------------------------------------- //

function UserInit($data)
{
  if (!isset($data['id'])) {
    $data['id'] = NewId('User');
  }
  if (!isset($data['data_type'])) {
    $data['data_type'] = "user_data";
  }

  if (!isset($data['create_date'])) {
    $data['create_date'] = GetCurrentTimeString();
  }

  if (!isset($data['active'])) {
    $data['active'] = true;
  }

  if (!isset($data['username'])) {
    $data['username'] = "";
  }

  if (!isset($data['phone'])) {
    $data['phone'] = "";
  }

  if (!isset($data['email'])) {
    $data['email'] = "";
  }

  if (!isset($data['password_data'])) {
    $data['password_data'] = "";
  }

  if (!isset($data['receive_update'])) {
    $data['receive_update'] = false;
  }

  if (!isset($data['agree_terms'])) {
    $data['agree_terms'] = false;
  }

  if (!isset($data['facebook_id'])) {
    $data['facebook_id'] = "";
  }

  if (!isset($data['facebook_key'])) {
    $data['facebook_key'] = "";
  }

  if (!isset($data['google_key'])) {
    $data['google_key'] = "";
  }

  if (!isset($data['apple_key'])) {
    $data['apple_key'] = "";
  }

  if (!isset($data['notification_id'])) {
    $data['notification_id'] = "";
  }

  if (!isset($data['verify_key'])) {
    $data['verify_key'] = "";
  }

  if (!isset($data['notification_on'])) {
    $data['notification_on'] = false;
  }

  if (!isset($data['user_type'])) {
    $data['user_type'] = ""; // end_user / staff
  }

  if (!isset($data['image'])) {
    $data['image'] = "";
  }

  return $data;
}

function CheckEmail($in_bound_data){
  $bucket = Bucket();
  $result = array("result" => "success", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if(!array_key_exists("email", $temp_data)){
    return json_encode(array("result" => "fail", "data" => "missing must key"));
  }

  $check_query = CouchbaseN1qlQuery::fromString("select raw(email) from " . BucketName() . " where data_type='user_data' and email=". json_encode($temp_data['email']) . " ");
  try {
    $check_rows = $bucket->query($check_query);
    $check_json = json_decode(json_encode($check_rows), true);
    if ($check_json["rows"] != null) {
      if (count($check_json["rows"]) > 0) {
          return json_encode(array("result" => "fail", "data" => "Email  has been used"));
      }
    }
  } catch (\Exception $e) { }

  return json_encode($result);
}

function CheckPhone($in_bound_data){
  $bucket = Bucket();
  $result = array("result" => "success", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if(!array_key_exists("phone", $temp_data)){
    return json_encode(array("result" => "fail", "data" => "missing must key"));
  }

  $check_query = CouchbaseN1qlQuery::fromString("select raw(phone) from " . BucketName() . " where data_type='user_data' and phone=". json_encode($temp_data['phone']) . " ");
  try {
    $check_rows = $bucket->query($check_query);
    $check_json = json_decode(json_encode($check_rows), true);
    if ($check_json["rows"] != null) {
      if (count($check_json["rows"]) > 0) {
          return json_encode(array("result" => "fail", "data" => "Phone has been used"));
      }
    }
  } catch (\Exception $e) { }
  
  return json_encode($result);
}

function UserRegister($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if(!array_key_exists("username", $temp_data) || !array_key_exists("phone", $temp_data) || !array_key_exists("password", $temp_data) || !array_key_exists("email", $temp_data)){
    return json_encode(array("result" => "fail", "data" => "missing must key"));
  }

  $check_query = CouchbaseN1qlQuery::fromString("select raw(email) from " . BucketName() . " where data_type='user_data' and email=". json_encode($temp_data['email']) . " ");
  try {
    $check_rows = $bucket->query($check_query);
    $check_json = json_decode(json_encode($check_rows), true);
    if ($check_json["rows"] != null) {
      if (count($check_json["rows"]) > 0) {
          return json_encode(array("result" => "fail", "data" => "email exist"));
      }
    }
  } catch (\Exception $e) { }

  $check_query = CouchbaseN1qlQuery::fromString("select raw(phone) from " . BucketName() . " where data_type='user_data' and phone=". json_encode($temp_data['phone']) . " ");
  try {
    $check_rows = $bucket->query($check_query);
    $check_json = json_decode(json_encode($check_rows), true);
    if ($check_json["rows"] != null) {
      if (count($check_json["rows"]) > 0) {
          return json_encode(array("result" => "fail", "data" => "Phone has been used"));
      }
    }
  } catch (\Exception $e) { }

  $temp_data = UserInit($temp_data);

  $temp_data['password_data'] = encrypt($temp_data['password'], "E", PasswordKey());
  unset($temp_data['password']);
  $temp_data['user_type'] = "end_user";

  //N1QL
  $query = CouchbaseN1qlQuery::fromString("UPSERT INTO " . BucketName() . " as data (KEY, VALUE) VALUES (\"user_" . $temp_data['id'] . "\"," . json_encode($temp_data) . ") RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]["data"] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          return json_encode(array("result" => "success", "data" => $user_data));
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function StaffRegister($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if(!array_key_exists("username", $temp_data) || !array_key_exists("phone", $temp_data) || !array_key_exists("password", $temp_data) || !array_key_exists("email", $temp_data)){
    return json_encode(array("result" => "success", "data" => "missing must key"));
  }

  $check_query = CouchbaseN1qlQuery::fromString("select raw(email) from " . BucketName() . " where data_type='user_data' and email=". json_encode($temp_data['email']) . " ");
  try {
    $check_rows = $bucket->query($check_query);
    $check_json = json_decode(json_encode($check_rows), true);
    if ($check_json["rows"] != null) {
      if (count($check_json["rows"]) > 0) {
          return json_encode(array("result" => "fail", "data" => "Email has been used"));
      }
    }
  } catch (\Exception $e) { }

  $temp_data = UserInit($temp_data);

  $temp_data['password_data'] = encrypt($temp_data['password'], "E", PasswordKey());
  unset($temp_data['password']);
  $temp_data['user_type'] = "staff";

  //N1QL
  $query = CouchbaseN1qlQuery::fromString("UPSERT INTO " . BucketName() . " as data (KEY, VALUE) VALUES (\"user_" . $temp_data['id'] . "\"," . json_encode($temp_data) . ") RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]["data"] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          return json_encode(array("result" => "success", "data" => $user_data));
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function UpdateUser($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if (!array_key_exists('id', $temp_data)) {
    return json_encode(array("result" => "fail", "data" => "value missing"));
  }
  $update_string = "";

  if (isset($temp_data['username'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " username = " . json_encode($temp_data['username']) . " ";
  }

  if (isset($temp_data['email'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " email = " . json_encode($temp_data['email']) . " ";
    $check_query = CouchbaseN1qlQuery::fromString("select raw(email) from " . BucketName() . " where data_type='user_data' and email=". json_encode($temp_data['email']) . " and id!=".$temp_data['id']." ");
    try {
      $check_rows = $bucket->query($check_query);
      $check_json = json_decode(json_encode($check_rows), true);
      if ($check_json["rows"] != null) {
        if (count($check_json["rows"]) > 0) {
            return json_encode(array("result" => "fail", "data" => "email exist"));
        }
      }
    } catch (\Exception $e) { }
  }

  if (isset($temp_data['phone'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " phone = " . json_encode($temp_data['phone']) . " ";
    $check_query = CouchbaseN1qlQuery::fromString("select raw(phone) from " . BucketName() . " where data_type='user_data' and phone=". json_encode($temp_data['phone']) . " and id!=".$temp_data['id']." ");
    try {
      $check_rows = $bucket->query($check_query);
      $check_json = json_decode(json_encode($check_rows), true);
      if ($check_json["rows"] != null) {
        if (count($check_json["rows"]) > 0) {
            return json_encode(array("result" => "fail", "data" => "phone exist"));
        }
      }
    } catch (\Exception $e) { }
  }
  
  if (isset($temp_data['password'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " password_data = " . json_encode(encrypt($temp_data['password'], "E", PasswordKey())) . " ";
  }

  if (isset($temp_data['receive_update'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " receive_update = " . json_encode($temp_data['receive_update']) . " ";
  }

  if (isset($temp_data['agree_terms'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " agree_terms = " . json_encode($temp_data['agree_terms']) . " ";
  }

  if (isset($temp_data['facebook_id'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " facebook_id = " . json_encode($temp_data['facebook_id']) . " ";
  }

  if (isset($temp_data['facebook_key'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " facebook_key = " . json_encode($temp_data['facebook_key']) . " ";
  }

  if (isset($temp_data['google_key'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " google_key = " . json_encode($temp_data['google_key']) . " ";
  }

  if (isset($temp_data['apple_key'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " apple_key = " . json_encode($temp_data['apple_key']) . " ";
  }

  if (isset($temp_data['notification_id'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " notification_id = " . json_encode($temp_data['notification_id']) . " ";
  }

  if (isset($temp_data['notification_on'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " notification_on = " . json_encode($temp_data['notification_on']) . " ";
  }

  if (isset($temp_data['image'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " image = " . json_encode($temp_data['image']) . " ";
  }

  $query = CouchbaseN1qlQuery::fromString("update " . BucketName() . " as data set " . $update_string . " where id=" . $temp_data['id'] . " and data_type='user_data' RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    // return json_encode($json);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]['data'] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          $result['data'] = $user_data;
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function GetAllUser(){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);

	$query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='user_data' order by id desc;");
	try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		$result = array("result"=>"success","data"=>[]);
		if($json["rows"]!=null){
				$result['data'] = $json["rows"];
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}

function GetUserById($in_bound_data){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);
  $temp_data = json_decode($in_bound_data,true);

	if(!array_key_exists('id',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing"));
	}

	$query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='user_data' and id=".$temp_data['id']." ;");
	try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		$result = array("result"=>"success","data"=>[]);
		if($json["rows"]!=null){
			if($json["rows"][0]!=null){
				$result['data'] = $json["rows"][0];
			}
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}

function Login($in_bound_data){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);
  $temp_data = json_decode($in_bound_data,true);

	if(!array_key_exists('email',$temp_data) || !array_key_exists('password',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing"));
	}

	$query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='user_data' and active=true and email=".json_encode($temp_data['email'])." and password_data=".json_encode(encrypt($temp_data['password'], "E", PasswordKey()))." ;");
	try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		if($json["rows"]!=null){
			if($json["rows"][0]!=null){
        $result = array("result"=>"success","data"=>[]);
				$result['data'] = $json["rows"][0];
        unset($result['data']['password_data']);
			}
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}

function ResetPasswordRequest($in_bound_data)
{
    $bucket = Bucket();
    $result = array("result" => "fail", "data" => 'request fail');
    $temp_data = json_decode($in_bound_data, true);
    if (!array_key_exists('email', $temp_data)) {
        return json_encode(array("result" => "fail", "data" => "value missing"));
    }
    if (!CheckEmailFormat($temp_data['email'])) {
        return json_encode(array("result" => "fail", "data" => "email format incorrect"));
    }

    $query2 = CouchbaseN1qlQuery::fromString("update " . BucketName() . " set verify_key='" . VerifyKeyGenerator() . "' where data_type=='user_data' and email == '" . $temp_data['email'] . "' ;");
    try {
        $bucket->query($query2);
        // SendEmail($temp_data['email'], $new_key);
        $result = array("result" => "success", "data" => 'request accepted');
    } catch (\Exception $e) {}

    return json_encode($result);
}
function ResetPasswordVerify($in_bound_data)
{
    $bucket = Bucket();
    $result = array("result" => "fail", "data" => 'verify fail');
    $temp_data = json_decode($in_bound_data, true);
    if (!array_key_exists('email', $temp_data) || !array_key_exists('verify_key', $temp_data)) {
        return json_encode(array("result" => "fail", "data" => "value missing"));
    }
    if (!CheckEmailFormat($temp_data['email'])) {
        return json_encode(array("result" => "fail", "data" => "email format incorrect"));
    }
    if (!string_valid($temp_data['verify_key']) || strlen($temp_data['verify_key']) != 6) {
        return json_encode(array("result" => "fail", "data" => "verify_key format incorrect"));
    }

    $query = CouchbaseN1qlQuery::fromString("select verify_key from " . BucketName() . " where data_type=='user_data' and email == '" . $temp_data['email'] . "' ;");
    try {
        $rows = $bucket->query($query);
        $json = json_decode(json_encode($rows), true);
        // $result = json_encode($rows);
        if ($json["rows"] != null) {
            if ($json["rows"][0] != null) {
                if ($json["rows"][0]['verify_key'] != null) {
                    if ($json["rows"][0]['verify_key'] == $temp_data['verify_key']) {
                        $new_password = RandomPasswordGenerator();
                        $query2 = CouchbaseN1qlQuery::fromString("update " . BucketName() . " set verify_key='" . VerifyKeyGenerator() . "', password_data='" . encrypt($new_password, 'E', PasswordKey()) . "' where data_type=='user_data' and email == '" . $temp_data['email'] . "' ;");
                        try {
                            $bucket->query($query2);
                        } catch (\Exception $e) {}
                        // SendNewPassword($temp_data['email'], $new_password);
                        $result = array("result" => "success", "data" => 'reset success');
                    }
                }
            }
        }
    } catch (\Exception $e) {}
    return json_encode($result);
}




function FacebookRegister($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if(!array_key_exists("facebook_id", $temp_data) || !array_key_exists("facebook_key", $temp_data)){
    return json_encode(array("result" => "fail", "data" => "missing must key"));
  }

  $temp_data = UserInit($temp_data);

  $temp_data['password_data'] = encrypt($temp_data['facebook_key'], "E", PasswordKey());
  $temp_data['user_type'] = "end_user";

  //N1QL
  $query = CouchbaseN1qlQuery::fromString("UPSERT INTO " . BucketName() . " as data (KEY, VALUE) VALUES (\"user_" . $temp_data['id'] . "\"," . json_encode($temp_data) . ") RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]["data"] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          return json_encode(array("result" => "success", "data" => $user_data));
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function FacebookLogin($in_bound_data){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);
  $temp_data = json_decode($in_bound_data,true);

	if(!array_key_exists('facebook_id',$temp_data) || !array_key_exists('facebook_key',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing"));
	}

	$query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='user_data' and active=true and facebook_id=".json_encode($temp_data['facebook_id'])." and password_data=".json_encode(encrypt($temp_data['facebook_key'], "E", PasswordKey()))." ;");
	try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		if($json["rows"]!=null){
			if($json["rows"][0]!=null){
        $result = array("result"=>"success","data"=>[]);
				$result['data'] = $json["rows"][0];
        unset($result['data']['password_data']);
			}
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}

function GoogleRegister($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if(!array_key_exists("username", $temp_data) || !array_key_exists("google_key", $temp_data) || !array_key_exists("email", $temp_data)){
    return json_encode(array("result" => "fail", "data" => "missing must key"));
  }

  $check_query = CouchbaseN1qlQuery::fromString("select raw(email) from " . BucketName() . " where data_type='user_data' and email=". json_encode($temp_data['email']) . " ");
  try {
    $check_rows = $bucket->query($check_query);
    $check_json = json_decode(json_encode($check_rows), true);
    if ($check_json["rows"] != null) {
      if (count($check_json["rows"]) > 0) {
          return json_encode(array("result" => "fail", "data" => "You have registered by this email"));
      }
    }
  } catch (\Exception $e) { }

  $temp_data = UserInit($temp_data);

  $temp_data['password_data'] = encrypt($temp_data['google_key'], "E", PasswordKey());
  $temp_data['user_type'] = "end_user";

  //N1QL
  $query = CouchbaseN1qlQuery::fromString("UPSERT INTO " . BucketName() . " as data (KEY, VALUE) VALUES (\"user_" . $temp_data['id'] . "\"," . json_encode($temp_data) . ") RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]["data"] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          return json_encode(array("result" => "success", "data" => $user_data));
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function GoogleLogin($in_bound_data){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);
  $temp_data = json_decode($in_bound_data,true);

	if(!array_key_exists('google_key',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing"));
	}

	$query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='user_data' and active=true and google_key=".json_encode($temp_data['google_key'])." and password_data=".json_encode(encrypt($temp_data['google_key'], "E", PasswordKey()))." ;");
	try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		if($json["rows"]!=null){
			if($json["rows"][0]!=null){
        $result = array("result"=>"success","data"=>[]);
				$result['data'] = $json["rows"][0];
        unset($result['data']['password_data']);
			}
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}


function AppleRegister($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if(!array_key_exists("apple_key", $temp_data)){
    return json_encode(array("result" => "fail", "data" => "missing must key"));
  }


	$query_get = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='apple_user_data' and apple_key='".$temp_data['apple_key']."' ;");
	try {
		$rows_get = $bucket->query($query_get);
		$json_get = json_decode(json_encode($rows_get),true);
		if($json_get["rows"]!=null){
			if($json_get["rows"][0]!=null){
        $temp_data['email'] = $json_get["rows"][0]['email'];
        $temp_data['username'] = $json_get["rows"][0]['username'];
			}
		}
	} catch (\Exception $e) {
  }
  
  $pos = strpos($temp_data['email'], "@privaterelay.appleid.com");
  if ($pos === false) {
  } else {
    $temp_data['apple_email'] = $temp_data['email'];
    $temp_data['email'] = "hidden_email";
  }

  $check_query = CouchbaseN1qlQuery::fromString("select raw(email) from " . BucketName() . " where data_type='user_data' and email=". json_encode($temp_data['email']) . " ");
  try {
    $check_rows = $bucket->query($check_query);
    $check_json = json_decode(json_encode($check_rows), true);
    if ($check_json["rows"] != null) {
      if (count($check_json["rows"]) > 0) {
          return json_encode(array("result" => "fail", "data" => "You have registered by this email"));
      }
    }
  } catch (\Exception $e) { }

  $temp_data = UserInit($temp_data);

  $temp_data['password_data'] = encrypt($temp_data['apple_key'], "E", PasswordKey());
  $temp_data['user_type'] = "end_user";

  //N1QL
  $query = CouchbaseN1qlQuery::fromString("UPSERT INTO " . BucketName() . " as data (KEY, VALUE) VALUES (\"user_" . $temp_data['id'] . "\"," . json_encode($temp_data) . ") RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]["data"] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          return json_encode(array("result" => "success", "data" => $user_data));
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function AppleLogin($in_bound_data){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);
  $temp_data = json_decode($in_bound_data,true);

	if(!array_key_exists('apple_key',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing"));
	}

	$query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='user_data' and active=true and apple_key=".json_encode($temp_data['apple_key'])." and password_data=".json_encode(encrypt($temp_data['apple_key'], "E", PasswordKey()))." ;");
	try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		if($json["rows"]!=null){
			if($json["rows"][0]!=null){
        $result = array("result"=>"success","data"=>[]);
				$result['data'] = $json["rows"][0];
        unset($result['data']['password_data']);
			}
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}



function AppleUserInit($data)
{
  if (!isset($data['id'])) {
    $data['id'] = NewId('AppleUser');
  }
  if (!isset($data['data_type'])) {
    $data['data_type'] = "apple_user_data";
  }

  if (!isset($data['create_date'])) {
    $data['create_date'] = GetCurrentTimeString();
  }

  if (!isset($data['username'])) {
    $data['username'] = "";
  }

  if (!isset($data['email'])) {
    $data['email'] = "";
  }

  if (!isset($data['apple_key'])) {
    $data['apple_key'] = "";
  }

  return $data;
}

function AddAppleUser($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if(!array_key_exists("username", $temp_data) || !array_key_exists("apple_key", $temp_data) || !array_key_exists("email", $temp_data)){
    return json_encode(array("result" => "fail", "data" => "missing must key"));
  }
  $temp_data = AppleUserInit($temp_data);
  $query = CouchbaseN1qlQuery::fromString("UPSERT INTO " . BucketName() . " as data (KEY, VALUE) VALUES (\"apple_user_" . $temp_data['id'] . "\"," . json_encode($temp_data) . ") RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]["data"] != null) {
          $user_data = $json["rows"][0]["data"];
          return json_encode(array("result" => "success", "data" => $user_data));
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function GetAppleUser($in_bound_data){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);
  $temp_data = json_decode($in_bound_data,true);

	if(!array_key_exists('apple_key',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing"));
	}

	$query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='apple_user_data' and apple_key='".$temp_data['apple_key']."' ;");
	try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		$result = array("result"=>"success","data"=>[]);
		if($json["rows"]!=null){
			if($json["rows"][0]!=null){
				$result['data'] = $json["rows"][0];
			}
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}
?>