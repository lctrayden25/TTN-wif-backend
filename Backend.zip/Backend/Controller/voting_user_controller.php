<?php
header("Access-Control-Allow-Origin: *");
ini_set("display_errors", "On");
error_reporting(E_ERROR);
date_default_timezone_set("Asia/Hong_Kong");
include_once('databasetool.php');
include_once('checker.php');
include_once('encryption.php');

// Agency ---------------------------------------------------------------------------------------------------------------- //

function UserInit($data)
{
  if (!isset($data['id'])) {
    $data['id'] = NewId('Voting_User');
  }

  if (!isset($data['artist_id'])) {
    $data['artist_id'] = -1;
  }
  if (!isset($data['data_type'])) {
    $data['data_type'] = "voting_user_data";
  }

  if (!isset($data['create_date'])) {
    $data['create_date'] = GetCurrentTimeString();
  }

  if (!isset($data['status'])) {
    $data['status'] = "active";
  }

  if (!isset($data['email'])) {
    $data['email'] = "";
  }

  if (!isset($data['password_data'])) {
    $data['password_data'] = "";
  }

  if (!isset($data['user_type'])) {
    $data['user_type'] = "";
  }

  return $data;
}

function CheckEmail($in_bound_data){
  $bucket = Bucket();
  $result = array("result" => "success", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if(!array_key_exists("email", $temp_data)){
    return json_encode(array("result" => "fail", "data" => "missing must key"));
  }

  $check_query = CouchbaseN1qlQuery::fromString("select raw(email) from " . BucketName() . " where data_type='voting_user_data' and email=". json_encode($temp_data['email']) . " ");
  try {
    $check_rows = $bucket->query($check_query);
    $check_json = json_decode(json_encode($check_rows), true);
    if ($check_json["rows"] != null) {
      if (count($check_json["rows"]) > 0) {
          return json_encode(array("result" => "fail", "data" => "Email  has been used"));
      }
    }
  } catch (\Exception $e) { }

  return json_encode($result);
}



function UserRegister($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if(!array_key_exists("password", $temp_data) || !array_key_exists("email", $temp_data)){
    return json_encode(array("result" => "fail", "data" => "missing must key"));
  }

  $check_query = CouchbaseN1qlQuery::fromString("select raw(email) from " . BucketName() . " where data_type='voting_user_data' and email=". json_encode($temp_data['email']) . " ");
  try {
    $check_rows = $bucket->query($check_query);
    $check_json = json_decode(json_encode($check_rows), true);
    if ($check_json["rows"] != null) {
      if (count($check_json["rows"]) > 0) {
          return json_encode(array("result" => "fail", "data" => "email exist"));
      }
    }
  } catch (\Exception $e) { }


  $temp_data = UserInit($temp_data);

  $temp_data['user_type'] = "member";

  $temp_data['password_data'] = encrypt($temp_data['password'], "E", PasswordKey());
  unset($temp_data['password']);

  //N1QL
  $query = CouchbaseN1qlQuery::fromString("UPSERT INTO " . BucketName() . " as data (KEY, VALUE) VALUES (\"voting_user_" . $temp_data['id'] . "\"," . json_encode($temp_data) . ") RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]["data"] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          return json_encode(array("result" => "success", "data" => $user_data));
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function AdminRegister($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if( !array_key_exists("password", $temp_data) || !array_key_exists("email", $temp_data)){
    return json_encode(array("result" => "success", "data" => "missing must key"));
  }

  $check_query = CouchbaseN1qlQuery::fromString("select raw(email) from " . BucketName() . " where data_type='voting_user_data' and email=". json_encode($temp_data['email']) . " ");
  try {
    $check_rows = $bucket->query($check_query);
    $check_json = json_decode(json_encode($check_rows), true);
    if ($check_json["rows"] != null) {
      if (count($check_json["rows"]) > 0) {
          return json_encode(array("result" => "fail", "data" => "Email has been used"));
      }
    }
  } catch (\Exception $e) { }

  $temp_data = UserInit($temp_data);

  $temp_data['password_data'] = encrypt($temp_data['password'], "E", PasswordKey());
  unset($temp_data['password']);
  $temp_data['user_type'] = "admin";

  //N1QL
  $query = CouchbaseN1qlQuery::fromString("UPSERT INTO " . BucketName() . " as data (KEY, VALUE) VALUES (\"voting_user_" . $temp_data['id'] . "\"," . json_encode($temp_data) . ") RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]["data"] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          return json_encode(array("result" => "success", "data" => $user_data));
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function UpdateUser($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if (!array_key_exists('id', $temp_data)) {
    return json_encode(array("result" => "fail", "data" => "value missing"));
  }
  $update_string = "";

  
  if (isset($temp_data['password'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " password_data = " . json_encode(encrypt($temp_data['password'], "E", PasswordKey())) . " ";
  }

  if (isset($temp_data['status'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " status = " . json_encode($temp_data['status']) . " ";
  }

  if (isset($temp_data['user_type'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " user_type = " . json_encode($temp_data['user_type']) . " ";
  }

  if (isset($temp_data['artist_id'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " artist_id = " . json_encode($temp_data['artist_id']) . " ";
  }


  $query = CouchbaseN1qlQuery::fromString("update " . BucketName() . " as data set " . $update_string . " where id=" . $temp_data['id'] . " and data_type='voting_user_data' RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    // return json_encode($json);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]['data'] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          $result['data'] = $user_data;
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}



function Login($in_bound_data){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);
  $temp_data = json_decode($in_bound_data,true);

	if(!array_key_exists('email',$temp_data) || !array_key_exists('password',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing"));
	}

	$query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='voting_user_data' and status='active' and email=".json_encode($temp_data['email'])." and password_data=".json_encode(encrypt($temp_data['password'], "E", PasswordKey()))." ;");
	try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		if($json["rows"]!=null){
			if($json["rows"][0]!=null){
        $result = array("result"=>"success","data"=>[]);
				$result['data'] = $json["rows"][0];
        unset($result['data']['password_data']);
			}
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}

function AdminLogin($in_bound_data){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);
  $temp_data = json_decode($in_bound_data,true);

	if(!array_key_exists('email',$temp_data) || !array_key_exists('password',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing"));
	}

	$query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='voting_user_data' and user_type='admin' and status='active' and email=".json_encode($temp_data['email'])." and password_data=".json_encode(encrypt($temp_data['password'], "E", PasswordKey()))." ;");
	try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		if($json["rows"]!=null){
			if($json["rows"][0]!=null){
        $result = array("result"=>"success","data"=>[]);
				$result['data'] = $json["rows"][0];
        unset($result['data']['password_data']);
			}
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}


?>