<?php
header("Access-Control-Allow-Origin: *");
ini_set("display_errors", "On");
error_reporting(E_All);
date_default_timezone_set("Asia/Hong_Kong");
include_once('databasetool.php');
include_once('checker.php');
include_once('encryption.php');

// Agency ---------------------------------------------------------------------------------------------------------------- //

function AlbumInit($data)
{
  if (!isset($data['id'])) {
    $data['id'] = NewId('Voting_Album');
  }

  if (!isset($data['data_type'])) {
    $data['data_type'] = "voting_album_data";
  }

  if (!isset($data['create_date'])) {
    $data['create_date'] = GetCurrentTimeString();
  }

  if (!isset($data['album_name'])) {
    $data['album_name'] = "";
  }

  if (!isset($data['approved'])){
    $data['approved'] = false;
  }

  if (!isset($data['release_date'])) {
    $data['release_date'] = "";
  }

  if (!isset($data['genre'])) {
    $data['genre'] = "";
  }

  if (!isset($data['album_publisher'])) {
    $data['album_publisher'] = "";
  }

  if (!isset($data['album_exceutive_producer'])) {
    $data['album_exceutive_producer'] = "";
  }

  if (!isset($data['album_cover_img_url'])) {
    $data['album_cover_img_url'] = "";
  }

  if (!isset($data['album_streaming_link'])) {
    $data['album_streaming_link'] = "";
  }

  if (!isset($data['track_list'])) {
    $data['track_list'] = [];
  }

  if (!isset($data['tag_list'])) {
    $data['tag_list'] = [];
  }

  if (!isset($data['status'])) {
    $data['status'] = "active";
  }

  return $data;
}



function NewAlbum($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if(      !array_key_exists("artist_id", $temp_data) 
        || !array_key_exists("album_name", $temp_data)
        || !array_key_exists("release_date", $temp_data)
        || !array_key_exists("genre", $temp_data)
        || !array_key_exists("album_publisher", $temp_data)
        || !array_key_exists("album_exceutive_producer", $temp_data)
        || !array_key_exists("album_cover_img_url", $temp_data)
        || !array_key_exists("album_streaming_link", $temp_data)
        || !array_key_exists("tracks", $temp_data)
    ){
    return json_encode(array("result" => "fail", "data" => "missing must key"));
  }

  if(count($temp_data['tracks'])<1){
    return json_encode(array("result" => "fail", "data" => "An album should at least has one track"));
  }

  $temp_data = AlbumInit($temp_data);
  for($i=0;$i<count($temp_data['tracks']);$i++){
    $temp_data['tracks'][$i]['release_date'] = $temp_data['release_date'];
    $temp_data['tracks'][$i]['genre'] = $temp_data['genre'];
    $temp_data['tracks'][$i]['artist_id'] = $temp_data['artist_id'];
    $temp_data['tracks'][$i]['tag_list'] = $temp_data['tag_list'];

    $new_track = json_decode(NewTrack(json_encode($temp_data['tracks'][$i])) ,true);

    if($new_track["result"] !="success"){
      return json_encode(array("result"=>"fail","data"=>"track insert fail","fail track"=>$temp_data['tracks'][$i]));
    }
    array_push($temp_data['track_list'],$new_track['data']['id']);
  }

  unset($temp_data['tracks']);



  //N1QL
  $query = CouchbaseN1qlQuery::fromString("UPSERT INTO " . BucketName() . " as data (KEY, VALUE) VALUES (\"voting_album_" . $temp_data['id'] . "\"," . json_encode($temp_data) . ") RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]["data"] != null) {

            $result["data"] = $json["rows"][0]["data"];
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function UpdateAlbum($in_bound_data)
{
  
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);
  $track_data = [];
  
  if (!array_key_exists('id', $temp_data)
      || !array_key_exists('track_list', $temp_data)
  ) {
    return json_encode(array("result" => "fail", "data" => "value missing"));
  }
  $update_string = "";
  
  if (isset($temp_data['artist_id'])) {

    $get_artist_data = json_decode( GetSingleDataByDataTypeAndIdExcludeDisabled(json_encode(array("data_type"=>"voting_artist_data","id"=>$temp_data['artist_id']))) ,true);
    if($get_artist_data['result'] !="success" || $get_artist_data['data'] ==null || empty($get_artist_data['data'])){
        return json_encode(array("result"=>"fail","data"=>"artist not found"));
    }


    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " artist_id = " . $temp_data['artist_id'] . " ";

    if(empty($track_data)){
      
      $get_track_data = json_decode(GetAllDataByDataTypeAndIdList(json_encode(array("data_type"=>"voting_track_data","id_list"=>$temp_data['track_list']))),true);
      
      if($get_track_data['result'] != "success"){
        return json_encode(array("result"=>"fail","data"=>"get track fail"));
      }
      
      $track_data = $get_track_data['data'];
      
    }
    
    for($i=0;$i<count($track_data);$i++){
      
      if(!in_array($track_data[$i]['id'], $temp_data['track_list'])){
        return json_encode(array("result"=>"fail","data"=>"get track fail"));
      }
      $track_data[$i]['artist_id'] = $temp_data['artist_id'];
    
    }

  }

  if (isset($temp_data['album_name'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " album_name = " . json_encode($temp_data['album_name']) . " ";
  }

  if (isset($temp_data['artist_label'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " artist_label = " . json_encode($temp_data['artist_label']) . " ";
  }

  if (isset($temp_data['approved'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    
    $update_string .= ($temp_data['approved']) ? ' approved = true' : ' approved = false'. " ";
  }

  if (isset($temp_data['release_date'])) {
    
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " release_date = " . json_encode($temp_data['release_date']) . " ";
    
    
    if(empty($track_data)){
      
      $get_track_data = json_decode(GetAllDataByDataTypeAndIdList(json_encode(array("data_type"=>"voting_track_data","id_list"=>$temp_data['track_list']))),true);
      
      if($get_track_data['result'] != "success"){
        return json_encode(array("result"=>"fail","data"=>"get track fail"));
      }
      
      $track_data = $get_track_data['data'];
      
    }
    
    for($i=0;$i<count($track_data);$i++){
      
      if(!in_array($track_data[$i]['id'], $temp_data['track_list'])){
        return json_encode(array("result"=>"fail","data"=>"get track fail"));
      }
      $track_data[$i]['release_date'] = $temp_data['release_date'];
    
    }
    
  }
  

  if (isset($temp_data['genre'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " genre = " . json_encode($temp_data['genre']) . " ";

    if(empty($track_data)){
      
      $get_track_data = json_decode(GetAllDataByDataTypeAndIdList(json_encode(array("data_type"=>"voting_track_data","id_list"=>$temp_data['track_list']))),true);
      
      if($get_track_data['result'] != "success"){
        return json_encode(array("result"=>"fail","data"=>"get track fail"));
      }
      
      $track_data = $get_track_data['data'];
      
    }
    
    for($i=0;$i<count($track_data);$i++){
      
      if(!in_array($track_data[$i]['id'], $temp_data['track_list'])){
        return json_encode(array("result"=>"fail","data"=>"get track fail"));
      }
      $track_data[$i]['genre'] = $temp_data['genre'];
    
    }
    

  }

  if (isset($temp_data['album_publisher'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " album_publisher = " . json_encode($temp_data['album_publisher']) . " ";
  }

  if (isset($temp_data['album_exceutive_producer'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " album_exceutive_producer = " . json_encode($temp_data['album_exceutive_producer']) . " ";
  }

  if (isset($temp_data['album_cover_img_url'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " album_cover_img_url = " . json_encode($temp_data['album_cover_img_url']) . " ";
  }


  if (isset($temp_data['album_streaming_link'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " album_streaming_link = " . json_encode($temp_data['album_streaming_link']) . " ";
  }

  if (isset($temp_data['track_list'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " track_list = " . json_encode($temp_data['track_list']) . " ";
  }
  
  if (isset($temp_data['tag_list'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " tag_list = " . json_encode($temp_data['tag_list']) . " ";

    if(empty($track_data)){
      
      $get_track_data = json_decode(GetAllDataByDataTypeAndIdList(json_encode(array("data_type"=>"voting_track_data","id_list"=>$temp_data['track_list']))),true);
      
      if($get_track_data['result'] != "success"){
        return json_encode(array("result"=>"fail","data"=>"get track fail"));
      }
      
      $track_data = $get_track_data['data'];
      
    }
    
    for($i=0;$i<count($track_data);$i++){
      
      if(!in_array($track_data[$i]['id'], $temp_data['track_list'])){
        return json_encode(array("result"=>"fail","data"=>"get track fail"));
      }
      $track_data[$i]['tag_list'] = $temp_data['tag_list'];
    
    }
    
  }




  if (isset($temp_data['status'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " status = " . json_encode($temp_data['status']) . " ";
  }

  
  if($update_string==""){
    return json_encode(array("result"=>"fail","data"=>"nothing update"));
  }

  if(!empty($track_data)){
    for($i=0;$i<count($track_data);$i++){
      $update_track_data = json_decode(UpdateTrack(json_encode($track_data[$i])),true);
      if($update_track_data['result'] !="success"){
        return json_encode(array("result"=>"fail","data"=>"fail to update track","fail_track"=>$track_data[$i]));
      }
    }
  }

  $query = CouchbaseN1qlQuery::fromString("update " . BucketName() . " as data set " . $update_string . " where id=" . $temp_data['id'] . " and data_type='voting_album_data' RETURNING * ;");
  
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    // return json_encode($json);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]['data'] != null) {
          $result['data'] = $json["rows"][0]['data'];
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}





?>