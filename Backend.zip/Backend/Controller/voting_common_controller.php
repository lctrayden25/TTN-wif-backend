<?php
header("Access-Control-Allow-Origin: *");
ini_set("display_errors", "On");
error_reporting(E_ERROR);
date_default_timezone_set("Asia/Hong_Kong");
include_once('databasetool.php');
include_once('checker.php');
include_once('encryption.php');




function GetSingleDataByDataTypeAndId($income_data)
{
    
    $bucket = Bucket();
    $result = array("result" => "fail", "data" => []);
    $temp_data = json_decode($income_data, true);

    if (
        !array_key_exists('data_type', $temp_data) ||
        !array_key_exists('id', $temp_data)
    ) {
        return json_encode(array("result" => "fail", "data" => "value missing"));
    }

    $query =  CouchbaseN1qlQuery::fromString("select raw data from " . BucketName() . " as data where data_type='" . $temp_data['data_type'] . "' and id = " . $temp_data['id'] . "; ");
    
    try {
      $check_rows = $bucket->query($query);
      $check_json = json_decode(json_encode($check_rows), true);

      $result = array("result"=>"success","data"=>[]);
      if (count($check_json["rows"]) > 0) {
          
        $result['data'] = $check_json["rows"][0];
      }
    } catch (\Exception $e) { }

    return json_encode($result);
}

function GetSingleDataByDataTypeAndIdExcludeDisabled($income_data)
{
    
    $bucket = Bucket();
    $result = array("result" => "fail", "data" => []);
    $temp_data = json_decode($income_data, true);

    if (
        !array_key_exists('data_type', $temp_data) ||
        !array_key_exists('id', $temp_data)
    ) {
        return json_encode(array("result" => "fail", "data" => "value missing"));
    }

    $query =  CouchbaseN1qlQuery::fromString("select raw data from " . BucketName() . " as data where data_type='" . $temp_data['data_type'] . "' and status = 'active' and id = " . $temp_data['id'] . "; ");
    
    try {
        $check_rows = $bucket->query($query);
        $check_json = json_decode(json_encode($check_rows), true);

        $result = array("result"=>"success","data"=>[]);
        if (count($check_json["rows"]) > 0) {
            
          $result['data'] = $check_json["rows"][0];
        }
      } catch (\Exception $e) { }

    return json_encode($result);
}



function GetAllDataByDataTypeAndIdList($income_data)
{
    $bucket = Bucket();
    $result = array("result" => "fail", "data" => "");
    $temp_data = json_decode($income_data, true);

    if (
        !array_key_exists('data_type', $temp_data) ||
        !array_key_exists('id_list', $temp_data)
    ) {
        return json_encode(array("result" => "fail", "data" => "value missing"));
    }

    $query = CouchbaseN1qlQuery::fromString("select raw data from " . BucketName() . " as data where data_type='" . $temp_data['data_type'] . "' and id in " . json_encode($temp_data['id_list']) . "; ");

    try {
        $check_rows = $bucket->query($query);
        $check_json = json_decode(json_encode($check_rows), true);
        if (count($check_json["rows"]) > 0) {
          $result = array("result"=>"success","data"=>[]);
          $result['data'] = $check_json["rows"];
        }
      } catch (\Exception $e) { }

    return json_encode($result);
}


function GetAllDataByDataType($income_data)
{
    $bucket = Bucket();
    $result = array("result" => "fail", "data" => "");
    $temp_data = json_decode($income_data, true);

    if (
        !array_key_exists('data_type', $temp_data)
    ) {
        return json_encode(array("result" => "fail", "data" => "value missing"));
    }

    $filter_str = "";

    if(array_key_exists('filter_page', $temp_data) 
        && $temp_data['filter_page'] !="" 
        && is_numeric($temp_data['filter_page']) 
        && array_key_exists('filter_limit', $temp_data) 
        && is_numeric($temp_data['filter_limit']) 
        && $temp_data['filter_limit'] !=""){
            $filter_str = ' OFFSET '.$temp_data['filter_limit']*$temp_data['filter_page'] .' LIMIT '. $temp_data['filter_limit'];
    }

    $query = CouchbaseN1qlQuery::fromString("select raw data from " . BucketName() . " as data where data_type='" . $temp_data['data_type'] . "'".$filter_str." order by id desc; ");
    
    try {
        $check_rows = $bucket->query($query);
        $check_json = json_decode(json_encode($check_rows), true);
        if (count($check_json["rows"]) > 0) {
          $result = array("result"=>"success","data"=>[]);
          $result['data'] = array("item_list"=>$check_json["rows"],"item_count"=>0);
          
          $query2 =  CouchbaseN1qlQuery::fromString("select Count(data) as total from " . BucketName() . " as data where data_type='" . $temp_data['data_type'] . "'".$filter_str."; ");
          try {
              $check_rows = $bucket->query($query2);
              $check_json = json_decode(json_encode($check_rows), true);
              
              if ($check_json["rows"] != null) {
                if (count($check_json["rows"]) > 0) {
                  if($check_json["rows"][0]['total']!=null){
                      $result['data']['item_count'] =  $check_json['rows'][0]['total'];
                  }
                }
              }
            } catch (\Exception $e) { }
        }
      } catch (\Exception $e) { }

    return json_encode($result);
}




function DeleteDataByDataTypeAndId($income_data)
{
    $bucket = Bucket();
    $result = array("result" => "fail", "data" => []);
    $temp_data = json_decode($income_data, true);

    if (!array_key_exists('id', $temp_data) || !array_key_exists('data_type', $temp_data)) {
        return json_encode(array("result" => "fail", "data" => "value missing"));
    }

    //return "update " . BucketName() . " set " . $update_string . " where data_type='course_data' and id=" . $temp_data['id'] . " RETURNING * ";
    $query = CouchbaseN1qlQuery::fromString("update " . BucketName() . " as data set data_type = 'deleted_" . $temp_data['data_type'] . "'  , disabled = true  where data_type='" . $temp_data['data_type'] . "' and id=" . $temp_data['id'] . " RETURNING * ");
    try {
        $check_rows = $bucket->query($query);
        $check_json = json_decode(json_encode($check_rows), true);
        if ($check_json["rows"] != null) {
          if (count($check_json["rows"]) > 0) {
            $result = array("result"=>"success","data"=>[]);
            $result['data'] = $check_json["rows"][0]['data'];
          }
        }
      } catch (\Exception $e) { }
    return json_encode($result);
}



?>