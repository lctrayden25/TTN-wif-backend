<?php
header("Access-Control-Allow-Origin: *");
ini_set("display_errors", "On");
error_reporting(E_ERROR);
date_default_timezone_set("Asia/Hong_Kong");
include_once('databasetool.php');
include_once('checker.php');
include_once('encryption.php');

// Agency ---------------------------------------------------------------------------------------------------------------- //

function CreditInit($data)
{
  if (!isset($data['id'])) {
    $data['id'] = NewId('Credit');
  }
  if (!isset($data['data_type'])) {
    $data['data_type'] = "credit_data";
  }

  if (!isset($data['create_date'])) {
    $data['create_date'] = GetCurrentTimeString();
  }

  if (!isset($data['active'])) {
    $data['active'] = true;
  }

  if (!isset($data['amount'])) {
    $data['amount'] = 0;
  }

  if (!isset($data['type'])) {
    $data['type'] = ""; // add / spend
  }

  if (!isset($data['user_id'])) {
    $data['user_id'] = -1;
  }

  return $data;
}

function AddCredit($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  // if(!array_key_exists("name", $temp_data) || !array_key_exists("date", $temp_data) || !array_key_exists("start_time", $temp_data) || !array_key_exists("end_time", $temp_data)){
  //   return json_encode(array("result" => "success", "data" => "missing must key"));
  // }

  $temp_data = CreditInit($temp_data);
  $temp_data['type'] = 'add';

  //N1QL
  $query = CouchbaseN1qlQuery::fromString("UPSERT INTO " . BucketName() . " as data (KEY, VALUE) VALUES (\"credit_" . $temp_data['id'] . "\"," . json_encode($temp_data) . ") RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]["data"] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          return json_encode(array("result" => "success", "data" => $user_data));
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function UseCredit($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  // if(!array_key_exists("name", $temp_data) || !array_key_exists("date", $temp_data) || !array_key_exists("start_time", $temp_data) || !array_key_exists("end_time", $temp_data)){
  //   return json_encode(array("result" => "success", "data" => "missing must key"));
  // }

  $temp_data = CreditInit($temp_data);
  $temp_data['type'] = 'spend';

  //N1QL
  $query = CouchbaseN1qlQuery::fromString("UPSERT INTO " . BucketName() . " as data (KEY, VALUE) VALUES (\"credit_" . $temp_data['id'] . "\"," . json_encode($temp_data) . ") RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]["data"] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          return json_encode(array("result" => "success", "data" => $user_data));
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function UpdateCredit($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if (!array_key_exists('id', $temp_data)) {
    return json_encode(array("result" => "fail", "data" => "value missing"));
  }
  $update_string = "";
  
  $data = UserInit($temp_data);

  if (isset($data['active'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " active = " . json_encode($data['active']) . " ";
  }

  $query = CouchbaseN1qlQuery::fromString("update " . BucketName() . " as data set " . $update_string . " where id=" . $temp_data['id'] . " and data_type='credit_data' RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    // return json_encode($json);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]['data'] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          $result['data'] = $user_data;
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function GetAllCredit(){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);

  $query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='credit_data' order by id desc;");
  try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		$result = array("result"=>"success","data"=>[]);
		if($json["rows"]!=null){
				$result['data'] = $json["rows"];
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}

function GetCreditById($in_bound_data){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);
  $temp_data = json_decode($in_bound_data,true);

	if(!array_key_exists('id',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing"));
	}

	$query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='credit_data' and id=".$temp_data['id']." ;");
  try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		$result = array("result"=>"success","data"=>[]);
		if($json["rows"]!=null){
			if($json["rows"][0]!=null){
				$result['data'] = $json["rows"][0];
			}
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}

function GetCreditOfUser($in_bound_data){
	$bucket = Bucket();
  $result = array("result"=>"success","data"=>0);
  $temp_data = json_decode($in_bound_data,true);

	if(!array_key_exists('id',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing"));
  }

	$query = CouchbaseN1qlQuery::fromString("select SUM(amount) as sum from ".BucketName()." where data_type='credit_data' and user_id=".$temp_data['id']." and type='add' ;");
  try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		if($json["rows"]!=null){
			if($json["rows"][0]!=null){
        if($json["rows"][0]['sum']!=null){
          $result['data'] += intval($json["rows"][0]['sum']);
        }
			}
		}
	} catch (\Exception $e) {
	}

	$query2 = CouchbaseN1qlQuery::fromString("select SUM(amount) as sum from ".BucketName()." where data_type='credit_data' and user_id=".$temp_data['id']." and type='spend' ;");
  try {
		$rows2 = $bucket->query($query2);
		$json2 = json_decode(json_encode($rows2),true);
		if($json2["rows"]!=null){
			if($json2["rows"][0]!=null){
        if($json2["rows"][0]['sum']!=null){
          $result['data'] -= intval($json2["rows"][0]['sum']);
        }
			}
		}
	} catch (\Exception $e) {
  }
  
	return json_encode($result);
}

?>