<?php
header("Access-Control-Allow-Origin: *");
ini_set("display_errors", "On");
error_reporting(E_ERROR);
date_default_timezone_set("Asia/Hong_Kong");
include_once('databasetool.php');
include_once('checker.php');
include_once('encryption.php');

// Agency ---------------------------------------------------------------------------------------------------------------- //

function TrackInit($data)
{
  if (!isset($data['id'])) {
    $data['id'] = NewId('Voting_Track');
  }

  if (!isset($data['data_type'])) {
    $data['data_type'] = "voting_track_data";
  }

  if (!isset($data['artist_id'])) {
    $data['artist_id'] = -1;
  }

  if (!isset($data['create_date'])) {
    $data['create_date'] = GetCurrentTimeString();
  }

  if (!isset($data['approved'])) {
    $data['approved'] = false;
  }

  if (!isset($data['track_name'])) {
    $data['track_name'] = "";
  }

  if (!isset($data['release_date'])){
    $data['release_date'] = "";
  }

  if (!isset($data['track_duration'])) {
    $data['track_duration'] = "";
  }

  if (!isset($data['genre'])) {
    $data['genre'] = "";
  }
  if (!isset($data['contact_person'])) {
    $data['contact_person'] = "";
  }
  if (!isset($data['contact_phone'])) {
    $data['contact_phone'] = "";
  }
  if (!isset($data['contact_email'])) {
    $data['contact_email'] = "";
  }

  if (!isset($data['role_of_contact_person'])) {
    $data['role_of_contact_person'] = "";
  }

  if (!isset($data['track_publisher'])) {
    $data['track_publisher'] = "";
  }

  if (!isset($data['featuring_artist'])) {
    $data['featuring_artist'] = "";
  }

  if (!isset($data['composer'])) {
    $data['composer'] = "";
  }

  if (!isset($data['composer_original_publisher'])) {
    $data['composer_original_publisher'] = "";
  }

  if (!isset($data['composer_sub_publisher'])) {
    $data['composer_sub_publisher'] = "";
  }

  if (!isset($data['lyricist'])) {
    $data['lyricist'] = "";
  }

  if (!isset($data['lyricist_original_publisher'])) {
    $data['lyricist_original_publisher'] = "";
  }

  if (!isset($data['lyricist_sub_publisher'])) {
    $data['lyricist_sub_publisher'] = "";
  }

  if (!isset($data['arranger'])) {
    $data['arranger'] = "";
  }

  if (!isset($data['producer'])) {
    $data['producer'] = "";
  }

  if (!isset($data['recording_engineer'])) {
    $data['recording_engineer'] = "";
  }

  if (!isset($data['mixing_engineer'])) {
    $data['mixing_engineer'] = "";
  }

  if (!isset($data['mastering_engineer'])) {
    $data['mastering_engineer'] = "";
  }

  if (!isset($data['lsrc'])) {
    $data['lsrc'] = "";
  }

  if (!isset($data['track_streaming_link'])) {
    $data['track_streaming_link'] = "";
  }
  if (!isset($data['souce_file_name'])) {
    $data['souce_file_name'] = "";
  }
  if (!isset($data['tag_list'])) {
    $data['tag_list'] = [];
  }

  if (!isset($data['status'])) {
    $data['status'] = "active";
  }

  return $data;
}



function NewTrack($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if(      !array_key_exists("artist_id", $temp_data) 
        || !array_key_exists("track_name", $temp_data)
        || !array_key_exists("release_date", $temp_data)
        || !array_key_exists("track_duration", $temp_data)
        || !array_key_exists("genre", $temp_data)
        // || !array_key_exists("contact_person", $temp_data)
        || !array_key_exists("role_of_contact_person", $temp_data)
        || !array_key_exists("track_publisher", $temp_data)
        || !array_key_exists("featuring_artist", $temp_data)
        || !array_key_exists("composer", $temp_data)
        || !array_key_exists("lyricist", $temp_data)
        || !array_key_exists("arranger", $temp_data)
        || !array_key_exists("producer", $temp_data)
        || !array_key_exists("recording_engineer", $temp_data)
        || !array_key_exists("mixing_engineer", $temp_data)
        || !array_key_exists("mastering_engineer", $temp_data)
        || !array_key_exists("lsrc", $temp_data)
        || !array_key_exists("track_streaming_link", $temp_data)
        || !array_key_exists("souce_file_name", $temp_data)
    ){
    return json_encode(array("result" => "fail", "data" => "missing must key"));
  }



  $get_artist_data = json_decode( GetSingleDataByDataTypeAndIdExcludeDisabled(json_encode(array("data_type"=>"voting_artist_data","id"=>$temp_data['artist_id']))) ,true);
  if($get_artist_data['result'] !="success" || $get_artist_data['data'] ==null || empty($get_artist_data['data'])){
      return json_encode(array("result"=>"fail","data"=>"artist not found"));
  }

  $temp_data = TrackInit($temp_data);

  //N1QL
  $query = CouchbaseN1qlQuery::fromString("UPSERT INTO " . BucketName() . " as data (KEY, VALUE) VALUES (\"voting_track_" . $temp_data['id'] . "\"," . json_encode($temp_data) . ") RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]["data"] != null) {
            $result["data"] = $json["rows"][0]["data"];
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function UpdateTrack($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if (!array_key_exists('id', $temp_data)) {
    return json_encode(array("result" => "fail", "data" => "value missing"));
  }
  $update_string = "";

  

  if (isset($temp_data['artist_id'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " artist_id = " . $temp_data['artist_id'] . " ";
  }

  if (isset($temp_data['approved'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    
    $update_string .= ($temp_data['approved']) ? ' approved = true' : ' approved = false'. " ";
  }

  if (isset($temp_data['track_name'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " track_name = " . json_encode($temp_data['track_name']) . " ";
  }

  if (isset($temp_data['composer'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " composer = " . json_encode($temp_data['composer']) . " ";
  }
  if (isset($temp_data['composer_original_publisher'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " composer_original_publisher = " . json_encode($temp_data['composer_original_publisher']) . " ";
  }

  if (isset($temp_data['composer_sub_publisher'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " composer_sub_publisher = " . json_encode($temp_data['composer_sub_publisher']) . " ";
  }
  
  if (isset($temp_data['contact_person'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " contact_person = " . json_encode($temp_data['contact_person']) . " ";
  }

  if (isset($temp_data['arranger'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " arranger = " . json_encode($temp_data['arranger']) . " ";
  }

  if (isset($temp_data['release_date'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " release_date = " . json_encode($temp_data['release_date']) . " ";
  }

  if (isset($temp_data['track_duration'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " track_duration = " . json_encode($temp_data['track_duration']) . " ";
  }

  if (isset($temp_data['featuring_artist'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " featuring_artist = " . json_encode($temp_data['featuring_artist']) . " ";
  }

  if (isset($temp_data['genre'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " genre = " . json_encode($temp_data['genre']) . " ";
  }

  if (isset($temp_data['lsrc'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " lsrc = " . json_encode($temp_data['lsrc']) . " ";
  }

  if (isset($temp_data['lyricist'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " lyricist = " . json_encode($temp_data['lyricist']) . " ";
  }

  if (isset($temp_data['lyricist_original_publisher'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " lyricist_original_publisher = " . json_encode($temp_data['lyricist_original_publisher']) . " ";
  }

  if (isset($temp_data['lyricist_sub_publisher'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " lyricist_sub_publisher = " . json_encode($temp_data['lyricist_sub_publisher']) . " ";
  }

  if (isset($temp_data['mastering_engineer'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " mastering_engineer = " . json_encode($temp_data['mastering_engineer']) . " ";
  }

  if (isset($temp_data['mixing_engineer'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " mixing_engineer = " . json_encode($temp_data['mixing_engineer']) . " ";
  }

  if (isset($temp_data['producer'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " producer = " . json_encode($temp_data['producer']) . " ";
  }

  if (isset($temp_data['recording_engineer'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " recording_engineer = " . json_encode($temp_data['recording_engineer']) . " ";
  }

  if (isset($temp_data['role_of_contact_person'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " role_of_contact_person = " . json_encode($temp_data['role_of_contact_person']) . " ";
  }

  if (isset($temp_data['souce_file_name'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " souce_file_name = " . json_encode($temp_data['souce_file_name']) . " ";
  }

  if (isset($temp_data['status'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " status = " . json_encode($temp_data['status']) . " ";
  }

  if (isset($temp_data['tag_list'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " tag_list = " . json_encode($temp_data['tag_list']) . " ";
  }

  if (isset($temp_data['contact_phone'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " contact_phone = " . json_encode($temp_data['contact_phone']) . " ";
  }

  if (isset($temp_data['contact_email'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " contact_email = " . json_encode($temp_data['contact_email']) . " ";
  }

  if (isset($temp_data['facebook_link'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " facebook_link = " . json_encode($temp_data['facebook_link']) . " ";
  }


  if (isset($temp_data['instagram_link'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " instagram_link = " . json_encode($temp_data['instagram_link']) . " ";
  }

  if (isset($temp_data['youtube_link'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " youtube_link = " . json_encode($temp_data['youtube_link']) . " ";
  }

  if (isset($temp_data['website_link'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " website_link = " . json_encode($temp_data['website_link']) . " ";
  }

  // if (isset($temp_data['artist_photo'])) {
  //   if($update_string != ""){
  //     $update_string .= " , ";
  //   }
  //   $update_string .= " artist_photo = '" . json_encode($temp_data['artist_photo']) . "' ";
  // }

  if($update_string==""){
    return json_encode(array("result"=>"fail","data"=>"nothing update"));
  }

  //return "update " . BucketName() . " as data set " . $update_string . " where id=" . $temp_data['id'] . " and data_type='voting_track_data' RETURNING * ;";
  $query = CouchbaseN1qlQuery::fromString("update " . BucketName() . " as data set " . $update_string . " where id=" . $temp_data['id'] . " and data_type='voting_track_data' RETURNING * ;");
  
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    // return json_encode($json);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]['data'] != null) {
          $result['data'] = $json["rows"][0]['data'];
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}


function UploadTrack($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  $file_name = "";
  
  if (isset($temp_data['upload_data'])) {
    $file_name = "track_upload_" . NewId('TrackUpload') . '.' . $temp_data['upload_file_type'];
    $file = fopen(dirname(dirname(dirname(__FILE__))) . "/Track/" . $file_name, "w");
    $data = explode(',', $temp_data['upload_data']);
    fwrite($file, base64_decode($data[1]));
    fclose($file);
    unset($temp_data['upload_data']);
    unset($temp_data['upload_file_type']);
    $result = array("result" => "success", "data" => $file_name);
  }
  return json_encode($result);
}


function GetTrackByFilter($income_data)
{
    
    $bucket = Bucket();
    $result = array("result" => "fail", "data" => []);
    $temp_data = json_decode($income_data, true);


    $filter_string = "";
    
    if(array_key_exists('filter_artist', $temp_data) &&  $temp_data['filter_artist'] !=""){
      $filter_string.= "AND artist_id=".$temp_data['filter_artist'] ." ";
    }


    if(array_key_exists('filter_approved', $temp_data)){
       
      $filter_string.="AND approved=".($temp_data['filter_approved'] ? 'true' : 'false') ." ";
      
    }


    if(array_key_exists('filter_track_name', $temp_data) &&  $temp_data['filter_track_name'] !=""){
      
      $filter_string .= "AND track_name=  '".$temp_data['filter_track_name'] ."' ";
    }

    if(array_key_exists('filter_composer_original_publisher', $temp_data) &&  $temp_data['filter_composer_original_publisher'] !=""){
      
      $filter_string .= "AND composer_original_publisher=  '".$temp_data['filter_composer_original_publisher'] ."' ";
    }

    if(array_key_exists('filter_composer', $temp_data) &&  $temp_data['filter_composer'] !=""){
      $filter_string .= "AND composer=  '".$temp_data['filter_composer'] ."' ";
    }

    if(array_key_exists('filter_composer_sub_publisher', $temp_data) &&  $temp_data['filter_composer_sub_publisher'] !=""){
      $filter_string .= "AND composer_sub_publisher=  '".$temp_data['filter_composer_sub_publisher'] ."' ";
    }

    if(array_key_exists('filter_contact_person', $temp_data) &&  $temp_data['filter_contact_person'] !=""){
      $filter_string .= "AND contact_person=  '".$temp_data['filter_contact_person'] ."' ";
    }

    if(array_key_exists('filter_track_duration', $temp_data) &&  $temp_data['filter_track_duration'] !=""){
      $filter_string .= "AND track_duration=  '".$temp_data['filter_track_duration'] ."' ";
    }

    if(array_key_exists('filter_featuring_artist', $temp_data) &&  $temp_data['filter_featuring_artist'] !=""){
      $filter_string .= "AND featuring_artist=  '".$temp_data['filter_featuring_artist'] ."' ";
    }

    if(array_key_exists('filter_genre', $temp_data) &&  $temp_data['filter_genre'] !=""){
      $filter_string .= "AND genre=  '".$temp_data['filter_genre'] ."' ";
    }

    if(array_key_exists('filter_lsrc', $temp_data) &&  $temp_data['filter_lsrc'] !=""){
      $filter_string .= "AND lsrc=  '".$temp_data['filter_lsrc'] ."' ";
    }

    if(array_key_exists('filter_lyricist', $temp_data) &&  $temp_data['filter_lyricist'] !=""){
      $filter_string .= "AND lyricist=  '".$temp_data['filter_lyricist'] ."' ";
    }

    if(array_key_exists('filter_lyricist_original_publisher', $temp_data) &&  $temp_data['filter_lyricist_original_publisher'] !=""){
      $filter_string .= "AND lyricist_original_publisher=  '".$temp_data['filter_lyricist_original_publisher'] ."' ";
    }

    if(array_key_exists('filter_lyricist_sub_publisher', $temp_data) &&  $temp_data['filter_lyricist_sub_publisher'] !=""){
      $filter_string .= "AND lyricist_sub_publisher=  '".$temp_data['filter_lyricist_sub_publisher'] ."' ";
    }

    if(array_key_exists('filter_mastering_engineer', $temp_data) &&  $temp_data['filter_mastering_engineer'] !=""){
      $filter_string .= "AND mastering_engineer=  '".$temp_data['filter_mastering_engineer'] ."' ";
    }

    if(array_key_exists('filter_producer', $temp_data) &&  $temp_data['filter_producer'] !=""){
      $filter_string .= "AND producer=  '".$temp_data['filter_producer'] ."' ";
    }

    if(array_key_exists('filter_recording_engineer', $temp_data) &&  $temp_data['filter_recording_engineer'] !=""){
      $filter_string .= "AND recording_engineer=  '".$temp_data['filter_recording_engineer'] ."' ";
    }

    if(array_key_exists('filter_role_of_contact_person', $temp_data) &&  $temp_data['filter_role_of_contact_person'] !=""){
      $filter_string .= "AND role_of_contact_person=  '".$temp_data['filter_role_of_contact_person'] ."' ";
    }

    if(array_key_exists('filter_souce_file_name', $temp_data) &&  $temp_data['filter_souce_file_name'] !=""){
      $filter_string .= "AND souce_file_name=  '".$temp_data['filter_souce_file_name'] ."' ";
    }
    if(array_key_exists('filter_status', $temp_data) &&  $temp_data['filter_status'] !=""){
      $filter_string .= "AND status=  '".$temp_data['filter_status'] ."' ";
    }
    if(array_key_exists('filter_tag', $temp_data) &&  $temp_data['filter_tag'] !=""){
      $filter_string .= "AND ".$temp_data['filter_tag'] ." IN  tag_list ";
    }
    if(array_key_exists('filter_contact_phone', $temp_data) &&  $temp_data['filter_contact_phone'] !=""){
      $filter_string .= "AND contact_phone=  '".$temp_data['filter_contact_phone'] ."' ";
    }

    if(array_key_exists('filter_contact_email', $temp_data) &&  $temp_data['filter_contact_email'] !=""){
      $filter_string .= "AND contact_email=  '".$temp_data['filter_contact_email'] ."' ";
    }
    
    $offset_string = "";

    if(array_key_exists('filter_page', $temp_data) 
    && is_numeric($temp_data['filter_page']) 
    && array_key_exists('filter_limit', $temp_data) 
    && is_numeric($temp_data['filter_limit'])){
        $offset_string .= ' OFFSET '.$temp_data['filter_limit']*$temp_data['filter_page'] .' LIMIT '. $temp_data['filter_limit'];
    }
    
    if($filter_string.$offset_string==""){
      $result = array("result" => "fail", "data" => "filter not found");
    }


    $query =  CouchbaseN1qlQuery::fromString("select raw data from " . BucketName() . " as data where data_type='voting_track_data' " . $filter_string." order by id desc ".$offset_string);
    
    try {
        $check_rows = $bucket->query($query);
        $check_json = json_decode(json_encode($check_rows), true);
        
        $result = array("result"=>"success","data"=>array("item_list"=>[],"item_count"=>0));
        
        if (count($check_json["rows"]) > 0) {
          $result['data'] = array("item_list"=>$check_json["rows"],"item_count"=>0);
          $query2 =  CouchbaseN1qlQuery::fromString("select Count(data) as total from " . BucketName() . " as data where data_type='voting_track_data' ".$filter_string."; ");
          try {
            $check_rows = $bucket->query($query2);
            $check_json = json_decode(json_encode($check_rows), true);
            
            if ($check_json["rows"] != null) {
              if (count($check_json["rows"]) > 0) {
                $result['data']['item_count'] =  $check_json['rows'][0]['total'];
              }
            }
          } catch (\Exception $e) { }
        }
      } catch (\Exception $e) { }

    return json_encode($result);
}





?>