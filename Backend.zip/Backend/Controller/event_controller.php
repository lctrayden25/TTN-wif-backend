<?php
header("Access-Control-Allow-Origin: *");
ini_set("display_errors", "On");
error_reporting(E_ERROR);
date_default_timezone_set("Asia/Hong_Kong");
include_once('databasetool.php');
include_once('checker.php');
include_once('encryption.php');

// Agency ---------------------------------------------------------------------------------------------------------------- //

function EventInit($data)
{
  if (!isset($data['id'])) {
    $data['id'] = NewId('Event');
  }
  if (!isset($data['data_type'])) {
    $data['data_type'] = "event_data";
  }

  if (!isset($data['create_date'])) {
    $data['create_date'] = GetCurrentTimeString();
  }

  if (!isset($data['active'])) {
    $data['active'] = true;
  }

  if (!isset($data['name'])) {
    $data['name'] = "";
  }

  if (!isset($data['date'])) {
    $data['date'] = "";
  }

  if (!isset($data['start_time'])) {
    $data['start_time'] = "";
  }

  if (!isset($data['end_time'])) {
    $data['end_time'] = "";
  }

  if (!isset($data['location'])) {
    $data['location'] = "";
  }

  if (!isset($data['description'])) {
    $data['description'] = "";
  }

  if (!isset($data['performers'])) {
    $data['performers'] = Array();
  }

  if (!isset($data['ticket_price'])) {
    $data['ticket_price'] = 0;
  }

  if (!isset($data['capacity'])) {
    $data['capacity'] = 0;
  }

  if (!isset($data['inventory'])) {
    $data['inventory'] = 0;
  }

  if (!isset($data['credit'])) {
    $data['credit'] = 0;
  }

  if (!isset($data['bonus'])) {
    $data['bonus'] = 0;
  }

  if (!isset($data['splash'])) {
    $data['splash'] = "";
  }

  return $data;
}

function NewEvent($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if(!array_key_exists("name", $temp_data) || !array_key_exists("date", $temp_data) || !array_key_exists("start_time", $temp_data) || !array_key_exists("end_time", $temp_data)){
    return json_encode(array("result" => "success", "data" => "missing must key"));
  }

  $temp_data = EventInit($temp_data);

  //N1QL
  $query = CouchbaseN1qlQuery::fromString("UPSERT INTO " . BucketName() . " as data (KEY, VALUE) VALUES (\"event_" . $temp_data['id'] . "\"," . json_encode($temp_data) . ") RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]["data"] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          return json_encode(array("result" => "success", "data" => $user_data));
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function UpdateEvent($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if (!array_key_exists('id', $temp_data)) {
    return json_encode(array("result" => "fail", "data" => "value missing"));
  }
  $update_string = "";
  
  $data = UserInit($temp_data);

  if (isset($data['active'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " active = " . json_encode($data['active']) . " ";
  }

  if (isset($data['name'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " name = " . json_encode($data['name']) . " ";
  }
  
  if (isset($data['date'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " date = " . json_encode($data['date']) . " ";
  }

  if (isset($data['start_time'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " start_time = " . json_encode($data['start_time']) . " ";
  }

  if (isset($data['end_time'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " end_time = " . json_encode($data['end_time']) . " ";
  }

  if (isset($data['location'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " location = " . json_encode($data['location']) . " ";
  }

  if (isset($data['description'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " description = " . json_encode($data['description']) . " ";
  }

  if (isset($data['performers'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " performers = " . json_encode($data['performers']) . " ";
  }

  if (isset($data['ticket_price'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " ticket_price = " . $data['ticket_price'] . " ";
  }

  if (isset($data['capacity'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " capacity = " . $data['capacity'] . " ";
  }

  if (isset($data['inventory'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " inventory = " . $data['inventory'] . " ";
  }

  if (isset($data['credit'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " credit = " . $data['credit'] . " ";
  }

  if (isset($data['bonus'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " bonus = " . $data['bonus'] . " ";
  }

  if (isset($data['splash'])) {
    $update_string .= " splash = " . json_encode($data['splash']) . " ";
  }

  $query = CouchbaseN1qlQuery::fromString("update " . BucketName() . " as data set " . $update_string . " where id=" . $temp_data['id'] . " and data_type='event_data' RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    // return json_encode($json);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]['data'] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          $result['data'] = $user_data;
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function GetAllEvent(){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);

  // $query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='event_data' order by id desc;");
  $query = CouchbaseN1qlQuery::fromString("SELECT ttn1 as event, ttn2 as album, ttn3 as comments, ttn4 as performers FROM '.BucketName().' as ttn1 LEFT JOIN '.BucketName().' as ttn2 ON ttn2.data_type='album_data' and ttn2.event_id=ttn1.id LEFT JOIN '.BucketName().' as ttn3 ON ttn3.data_type='comment_data' and ttn3.event_id=ttn1.id LEFT JOIN '.BucketName().' as ttn4 ON ttn4.data_type='performer_data' and ttn4.event_id=ttn1.id WHERE ttn1.data_type = 'event_data' order by ttn1.id desc");
	try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		$result = array("result"=>"success","data"=>[]);
		if($json["rows"]!=null){
				$result['data'] = $json["rows"];
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}

function GetEventById($in_bound_data){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);
  $temp_data = json_decode($in_bound_data,true);

	if(!array_key_exists('id',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing"));
	}

	// $query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='event_data' and id=".$temp_data['id']." ;");
  $query = CouchbaseN1qlQuery::fromString("SELECT ttn1 as event, ttn2 as album, ttn3 as comments, ttn4 as performers FROM '.BucketName().' as ttn1 LEFT JOIN '.BucketName().' as ttn2 ON ttn2.data_type='album_data' and ttn2.event_id=ttn1.id LEFT JOIN '.BucketName().' as ttn3 ON ttn3.data_type='comment_data' and ttn3.event_id=ttn1.id LEFT JOIN '.BucketName().' as ttn4 ON ttn4.data_type='performer_data' and ttn4.event_id=ttn1.id WHERE ttn1.data_type = 'event_data' and ttn1.id=".$temp_data['id']." order by ttn1.id desc");
	try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		$result = array("result"=>"success","data"=>[]);
		if($json["rows"]!=null){
			if($json["rows"][0]!=null){
				$result['data'] = $json["rows"][0];
			}
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}

function GetEventByIdList($in_bound_data){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);
  $temp_data = json_decode($in_bound_data,true);

	if(!array_key_exists('id_list',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing"));
	}

	$query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='event_data' and id in ".$temp_data['id_list']." ;");
  try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		$result = array("result"=>"success","data"=>[]);
		if($json["rows"]!=null){
				$result['data'] = $json["rows"];
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}

?>