<?php
function string_valid($input){
	$valid = false;
	if(isset($input) && !is_null($input) && !empty($input)){
		$valid = true;
	}
	return $valid;
}
function GetCurrentTimeString(){
  return date("Y-m-d")."T".date("H:i:s")."Z";
}
function GetNDayLaterTimeString($days){
	$date = date("Y-m-d");
  return date("Y-m-d",strtotime($date. ' + '.$days.' days'))."T".date("H:i:s")."Z";
}
function GetNDayBeforeTimeString($days){
	$date = date("Y-m-d");
  return date("Y-m-d",strtotime($date. ' - '.$days.' days'))."T".date("H:i:s")."Z";
}
function GetNDayLaterDateString($days){
	$date = date("Y-m-d");
  return date("Y-m-d",strtotime($date. ' + '.$days.' days'));
}
function GetNDayLaterFromDateString($from, $days){
	$date = date($from);
  return date("Y-m-d",strtotime($date. ' + '.$days.' days'));
}
function GetCurrentTime(){
  return strtotime(GetCurrentTimeString())*1000;
}
function ConvertTimeToString($date,$time){
  return strtotime($date."T".$time.":0Z")*1000;
}
function GetTargetTime($time_string){
  return strtotime($time_string)*1000;
}
function CheckEmailFormat($input){
	$valid = false;
	if(isset($input) && !is_null($input) && !empty($input)){
		if(filter_var($input, FILTER_VALIDATE_EMAIL)){
			$valid = true;
		}
	}
	return $valid;
}
function VerifyKeyGenerator() {
	$length = 6;
  $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  $charactersLength = strlen($characters);
  $randomString = '';
  for ($i = 0; $i < $length; $i++) {
      $randomString .= $characters[rand(0, $charactersLength - 1)];
  }
  return $randomString;
}
function RandomPasswordGenerator() {
	$length = 12;
  $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()-=_+|~?<>[]{}';
  $charactersLength = strlen($characters);
  $randomString = '';
  for ($i = 0; $i < $length; $i++) {
      $randomString .= $characters[rand(0, $charactersLength - 1)];
  }
  return $randomString;
}
function deleteElement($element, &$array){
    $index = array_search($element, $array);
    if($index !== false){
        unset($array[$index]);
    }
}
?>
