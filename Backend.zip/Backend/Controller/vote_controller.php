<?php
header("Access-Control-Allow-Origin: *");
ini_set("display_errors", "On");
error_reporting(E_ERROR);
date_default_timezone_set("Asia/Hong_Kong");
include_once('databasetool.php');
include_once('checker.php');
include_once('encryption.php');

// Agency ---------------------------------------------------------------------------------------------------------------- //

function VoteInit($data)
{
  if (!isset($data['id'])) {
    $data['id'] = NewId('Vote');
  }
  if (!isset($data['data_type'])) {
    $data['data_type'] = "vote_data";
  }

  if (!isset($data['create_date'])) {
    $data['create_date'] = GetCurrentTimeString();
  }

  if (!isset($data['active'])) {
    $data['active'] = true;
  }

  if (!isset($data['date'])) {
    $data['date'] = "";
  }

  if (!isset($data['time'])) {
    $data['time'] = "";
  }

  if (!isset($data['questions'])) {
    $data['questions'] = Array();
  }

  return $data;
}

function NewVote($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  // if(!array_key_exists("name", $temp_data) || !array_key_exists("date", $temp_data) || !array_key_exists("start_time", $temp_data) || !array_key_exists("end_time", $temp_data)){
  //   return json_encode(array("result" => "success", "data" => "missing must key"));
  // }

  $temp_data = VoteInit($temp_data);

  //N1QL
  $query = CouchbaseN1qlQuery::fromString("UPSERT INTO " . BucketName() . " as data (KEY, VALUE) VALUES (\"vote_" . $temp_data['id'] . "\"," . json_encode($temp_data) . ") RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]["data"] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          return json_encode(array("result" => "success", "data" => $user_data));
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function UpdateVote($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if (!array_key_exists('id', $temp_data)) {
    return json_encode(array("result" => "fail", "data" => "value missing"));
  }
  $update_string = "";
  
  $data = UserInit($temp_data);

  if (isset($data['active'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " active = " . json_encode($data['active']) . " ";
  }

  if (isset($data['date'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " date = " . json_encode($data['date']) . " ";
  }

  if (isset($data['time'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " time = " . json_encode($data['time']) . " ";
  }

  if (isset($data['questions'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " questions = " . json_encode($data['questions']) . " ";
  }

  $query = CouchbaseN1qlQuery::fromString("update " . BucketName() . " as data set " . $update_string . " where id=" . $temp_data['id'] . " and data_type='vote_data' RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    // return json_encode($json);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]['data'] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          $result['data'] = $user_data;
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function GetAllVote(){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);

  $query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='vote_data' order by id desc;");
  try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		$result = array("result"=>"success","data"=>[]);
		if($json["rows"]!=null){
				$result['data'] = $json["rows"];
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}

function GetVoteById($in_bound_data){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);
  $temp_data = json_decode($in_bound_data,true);

	if(!array_key_exists('id',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing"));
	}

	$query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='vote_data' and id=".$temp_data['id']." ;");
  try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		$result = array("result"=>"success","data"=>[]);
		if($json["rows"]!=null){
			if($json["rows"][0]!=null){
				$result['data'] = $json["rows"][0];
			}
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}


function VoteResultInit($data)
{
  if (!isset($data['id'])) {
    $data['id'] = NewId('VoteResult');
  }
  if (!isset($data['data_type'])) {
    $data['data_type'] = "vote_result_data";
  }

  if (!isset($data['create_date'])) {
    $data['create_date'] = GetCurrentTimeString();
  }

  if (!isset($data['active'])) {
    $data['active'] = true;
  }

  if (!isset($data['user_id'])) {
    $data['user_id'] = -1;
  }

  if (!isset($data['vote_id'])) {
    $data['vote_id'] = -1;
  }

  if (!isset($data['answer'])) {
    $data['answer'] = Array();
  }

  return $data;
}

function NewVoteResult($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  // if(!array_key_exists("name", $temp_data) || !array_key_exists("date", $temp_data) || !array_key_exists("start_time", $temp_data) || !array_key_exists("end_time", $temp_data)){
  //   return json_encode(array("result" => "success", "data" => "missing must key"));
  // }

  $temp_data = VoteResultInit($temp_data);

  //N1QL
  $query = CouchbaseN1qlQuery::fromString("UPSERT INTO " . BucketName() . " as data (KEY, VALUE) VALUES (\"vote_result_" . $temp_data['id'] . "\"," . json_encode($temp_data) . ") RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]["data"] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          return json_encode(array("result" => "success", "data" => $user_data));
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function UpdateVoteResult($in_bound_data)
{
  $bucket = Bucket();
  $result = array("result" => "fail", "data" => []);
  $temp_data = json_decode($in_bound_data, true);

  if (!array_key_exists('id', $temp_data)) {
    return json_encode(array("result" => "fail", "data" => "value missing"));
  }
  $update_string = "";
  
  $data = UserInit($temp_data);

  if (isset($data['user_id'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " user_id = " . $data['user_id'] . " ";
  }

  if (isset($data['vote_id'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " vote_id = " . $data['vote_id'] . " ";
  }

  if (isset($data['answer'])) {
    if($update_string != ""){
      $update_string .= " , ";
    }
    $update_string .= " answer = " . json_encode($data['answer']) . " ";
  }

  $query = CouchbaseN1qlQuery::fromString("update " . BucketName() . " as data set " . $update_string . " where id=" . $temp_data['id'] . " and data_type='vote_result_data' RETURNING * ;");
  try {
    $rows = $bucket->query($query);
    $json = json_decode(json_encode($rows), true);
    $result = array("result" => "success", "data" => []);
    // return json_encode($json);
    if ($json["rows"] != null) {
      if ($json["rows"][0] != null) {
        if ($json["rows"][0]['data'] != null) {
          $user_data = $json["rows"][0]["data"];
          unset($user_data['password_data']);
          $result['data'] = $user_data;
        }
      }
    }
  } catch (\Exception $e) { }
  return json_encode($result);
}

function GetAllVoteResult(){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);

  $query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='vote_result_data' order by id desc;");
  try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		$result = array("result"=>"success","data"=>[]);
		if($json["rows"]!=null){
				$result['data'] = $json["rows"];
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}

function GetVoteResultById($in_bound_data){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);
  $temp_data = json_decode($in_bound_data,true);

	if(!array_key_exists('id',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing"));
	}

	$query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='vote_result_data' and id=".$temp_data['id']." ;");
  try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		$result = array("result"=>"success","data"=>[]);
		if($json["rows"]!=null){
			if($json["rows"][0]!=null){
				$result['data'] = $json["rows"][0];
			}
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}

function GetVoteResultByVoteId($in_bound_data){
	$bucket = Bucket();
  $result = array("result"=>"fail","data"=>[]);
  $temp_data = json_decode($in_bound_data,true);

	if(!array_key_exists('vote_id',$temp_data)){
		return json_encode(array("result"=>"fail","data"=>"value missing"));
	}

	$query = CouchbaseN1qlQuery::fromString("select raw data from ".BucketName()." as data where data_type='vote_result_data' and vote_id=".$temp_data['vote_id']." order by id desc ;");
  try {
		$rows = $bucket->query($query);
		$json = json_decode(json_encode($rows),true);
		$result = array("result"=>"success","data"=>[]);
		if($json["rows"]!=null){
				$result['data'] = $json["rows"];
		}
	} catch (\Exception $e) {
	}
	return json_encode($result);
}
?>