<?php
header("Access-Control-Allow-Origin: *");
ini_set("display_errors","On");
error_reporting(E_ALL);
date_default_timezone_set("Asia/Hong_Kong");
include('voting_require_files.php');

$result = json_encode(array("result"=>"fail", "data"=>"request fail"));

if(array_key_exists('ping',$_POST)){
	$result = "pong";
}

if(array_key_exists('current_datetime_string',$_POST)){
	$result = GetCurrentTimeString();
}

//common function
if (array_key_exists('get_single_data_by_data_type_and_id', $_POST)) {
    $result = GetSingleDataByDataTypeAndId($_POST['get_single_data_by_data_type_and_id']);
}

if (array_key_exists('get_single_data_by_data_type_and_id_exclude_disabled', $_POST)) {
    $result = GetSingleDataByDataTypeAndIdExcludeDisabled($_POST['get_single_data_by_data_type_and_id_exclude_disabled']);
}


if (array_key_exists('get_all_data_by_data_type_and_id_list', $_POST)) {
    $result = GetAllDataByDataTypeAndIdList($_POST['get_all_data_by_data_type_and_id_list']);
}
if (array_key_exists('get_all_data_by_data_type', $_POST)) {
    $result = GetAllDataByDataType($_POST['get_all_data_by_data_type']);
}

if (array_key_exists('delete_data_by_data_type_and_id', $_POST)) {
    $result = DeleteDataByDataTypeAndId($_POST['delete_data_by_data_type_and_id']);
}
if(array_key_exists('upload_file',$_POST)){
	$result = UploadImage($_POST['upload_file']);
}


//user function
if(array_key_exists('user_register',$_POST)){
	$result = UserRegister($_POST['user_register']);
}

if(array_key_exists('admin_register',$_POST)){
	$result = AdminRegister($_POST['admin_register']);
}

if(array_key_exists('admin_login',$_POST)){
	$result = AdminRegister($_POST['admin_login']);
}

if(array_key_exists('update_user',$_POST)){
	$result = UpdateUser($_POST['update_user']);
}

if(array_key_exists('login',$_POST)){
	$result = Login($_POST['login']);
}

if(array_key_exists('admin_login',$_POST)){
	$result = AdminLogin($_POST['admin_login']);
}

//artist function
if(array_key_exists('new_artist',$_POST)){
	$result = NewArtist($_POST['new_artist']);
}
if(array_key_exists('update_artist',$_POST)){
	$result = UpdateArtist($_POST['update_artist']);
}


//track data
if(array_key_exists('new_track',$_POST)){
	$result = NewTrack($_POST['new_track']);
}
if(array_key_exists('update_track',$_POST)){
	$result = Updatetrack($_POST['update_track']);
}
if(array_key_exists('upload_track',$_POST)){
	$result = UploadTrack($_POST['upload_track']);
}
if(array_key_exists('get_track_by_filter',$_POST)){
	$result = GetTrackByFilter($_POST['get_track_by_filter']);
}

//album data
if(array_key_exists('new_album',$_POST)){
	$result = NewAlbum($_POST['new_album']);
}
if(array_key_exists('update_album',$_POST)){
	$result = UpdateAlbum($_POST['update_album']);
}





echo $result;
?>
